#include "Notifications.h"
#include "../../Manager.h"
#include "../../Client.h"
#include "../../../Include/imgui/imgui.h"
#include "../../../Utils/Render/ImGuiUtils.h"
#include <d2d1.h>
#include <d2d1helper.h>
#include <dwrite.h>


void NotificationsModule::onImGuiRender() {

}