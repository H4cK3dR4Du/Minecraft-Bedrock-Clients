#pragma once

class ActorOwnerComponent
{
public:
	class Actor* actor;
};