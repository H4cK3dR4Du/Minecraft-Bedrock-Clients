#pragma once

enum class GameType
{
	SURVIVAL,
	CREATIVE,
	ADVENTURE,
	INVALID,
	STILL_INVALID,
	DEFAULT,
	SPECTATOR
};

struct ActorGameTypeComponent
{
	GameType gametype;
};