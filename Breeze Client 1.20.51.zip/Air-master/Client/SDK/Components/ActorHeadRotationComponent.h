#pragma once

#include <Math/Math.h>

struct ActorHeadRotationComponent {
	float headRot;
	float oldHeadRot;
};