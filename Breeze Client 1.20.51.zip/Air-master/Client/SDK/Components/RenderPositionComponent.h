#pragma once
#include "../../Utils/Utils.h"

struct RenderPositionComponent {
public:
	Vec3<float> renderPos;
};