#pragma once

struct RuntimeIDComponent
{
	int runtimeId;
};