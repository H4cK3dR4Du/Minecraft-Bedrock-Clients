#pragma once

template<typename T>
class FlagComponent
{
public:
	T flags;
};