#pragma once

struct AttributesComponent
{
	void* map;
};