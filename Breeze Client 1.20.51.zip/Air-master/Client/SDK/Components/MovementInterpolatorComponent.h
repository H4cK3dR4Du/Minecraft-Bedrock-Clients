#pragma once
#include "../../Utils/Utils.h"

struct MovementInterpolatorComponent
{
    Vec2<float> viewAngles;
    Vec2<float> prevViewAngles;
};