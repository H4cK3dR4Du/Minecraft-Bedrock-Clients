#pragma once

template<typename T>
class ActorFlagComponent
{
	T flags;
};