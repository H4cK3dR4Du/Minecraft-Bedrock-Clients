#pragma once

class JumpControlComponent
{
	bool canJump;
};