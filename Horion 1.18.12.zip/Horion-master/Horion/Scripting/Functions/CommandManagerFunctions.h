#pragma once

#include "../ScriptManager.h"
#include "../../Command/CommandMgr.h"

class CommandManagerFunctions {
public:
	DECL_FUN(executeCommand);
};
