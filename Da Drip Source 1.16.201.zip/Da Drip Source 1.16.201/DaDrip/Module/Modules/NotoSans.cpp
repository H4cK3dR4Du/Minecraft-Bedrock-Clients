#include "NotoSans.h"
NotoSans::NotoSans() : IModule(0, Category::VISUAL, "NotoSans") {
}

NotoSans::~NotoSans() {
}
const char* NotoSans::getModuleName() {
	return "NotoSans";
}