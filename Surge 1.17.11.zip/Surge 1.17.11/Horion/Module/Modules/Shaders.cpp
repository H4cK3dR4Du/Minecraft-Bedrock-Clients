#include "Shaders.h"

Shaders::Shaders() : IModule(0, Category::VISUAL, "Shaderzz") {
}
Shaders::~Shaders() {
}
const char* Shaders::getModuleName() {
	return "Shaders";
}
