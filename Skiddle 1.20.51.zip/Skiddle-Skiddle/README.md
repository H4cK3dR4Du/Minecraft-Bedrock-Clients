This client is fully updated to 1.20.51 please fix the crash! 
