#pragma once

// meowmeowcat12#2200 / cronic DEVEOPER credits lol
enum class Action : __int8 {
    STOP_RIDING = 3,
    INTERACT_UPDATE = 4,
    NPC_OPEN = 5,
    OPEN_INVENTORY = 6
};