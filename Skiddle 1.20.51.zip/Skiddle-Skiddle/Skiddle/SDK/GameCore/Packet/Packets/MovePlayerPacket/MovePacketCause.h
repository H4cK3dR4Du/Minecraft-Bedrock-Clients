#pragma once

enum MovePacketCause {
	MOVE_PACKET_CAUSE_UNKNOWN = 0,
	PROJECTILE = 1,
	CHORUS_FRUIT = 2,
	COMMAND = 3,
	BEHAVIOR = 4
};