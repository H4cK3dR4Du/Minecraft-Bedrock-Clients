#pragma once

enum MovePacketMode {
	MOVE_PACKET_MODE_NORMAL = 0,
	_RESET = 1,
	TELEPORT = 2,
	ROTATION = 3
};