#pragma once

struct PlayerBlockAction
{
	int action;
	Vector3<int> pos;
	int32_t blockFace;
};