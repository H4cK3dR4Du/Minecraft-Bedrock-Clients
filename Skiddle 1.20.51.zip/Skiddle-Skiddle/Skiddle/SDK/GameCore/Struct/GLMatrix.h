#pragma once

struct GLMatrix {
public:
	float matrix[16];
	float matrix_nest[4][4];
};