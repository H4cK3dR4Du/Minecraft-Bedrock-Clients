#pragma once

class UIScene {
public:
	void getScreenName(TextHolder* txt) {
		CallVFunc<68, void, TextHolder*>(this, txt); //84 //92 //107 
	}
};
