#pragma once

class MaterialPtr
{
private:
	char pad_0x0[0x138];
};