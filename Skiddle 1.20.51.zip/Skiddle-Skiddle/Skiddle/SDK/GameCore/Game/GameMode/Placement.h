#pragma once

enum Placement
{
    Down, Up
};