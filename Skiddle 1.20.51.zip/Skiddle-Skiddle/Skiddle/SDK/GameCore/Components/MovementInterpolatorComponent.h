#pragma once

class MovementInterpolatorComponent
{
public:
	Vector2<float> Rotations; //0x0000 
	Vector2<float> PrevRotations; //0x0008 
};