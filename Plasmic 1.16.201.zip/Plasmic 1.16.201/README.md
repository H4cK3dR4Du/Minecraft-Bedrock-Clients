# Plasmic Client = Epic Gaming Client
Plasmic Client is the third,( technically second as helix = skid )
MCBE Legit PvP, with many unique features.

## Warning
There might be a Discord token logger in this. Use at your own risk.
