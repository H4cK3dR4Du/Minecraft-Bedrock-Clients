#pragma once
#include "../Module.h"

class VisualTesting : public VisualModule {
public:
	VisualTesting();
	virtual void onRender() override;

};

