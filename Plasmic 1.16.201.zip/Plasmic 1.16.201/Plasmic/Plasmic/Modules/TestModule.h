#pragma once
#include "../Module.h"

class TestModule : public Module {
	public:

		TestModule();

		
		virtual void onRender();

};

