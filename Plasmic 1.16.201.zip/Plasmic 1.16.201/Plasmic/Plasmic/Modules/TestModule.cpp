#include "TestModule.h"


TestModule::TestModule() : Module("TestModule", 0, "This is a module used to test stuff") {

}



void TestModule::onRender() {
	
}

