#pragma once
#include "../Module.h"

class Fullbright : public Module {

public:

	Fullbright() : Module("Fullbright", 0, mltext("Can show you things that you never saw before.\nSo much brightness everything is clear now.", "Peut vous montrer des choses que vous n'avez jamais vue avant.\nTant de luminosite, tout est claire maintenant.")) {

	}



};

