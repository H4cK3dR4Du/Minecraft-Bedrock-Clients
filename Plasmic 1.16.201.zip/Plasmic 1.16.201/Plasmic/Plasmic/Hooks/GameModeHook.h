#pragma once
#include "../Module.h"

class GamemodeTickHook : public Hook {

	virtual void init() override;

};

class SurvivalModeTickHook : public Hook {

	virtual void init() override;

};

