#pragma once

#include "../Module.h"

class RenderContextHook : public Hook {
public:

	virtual void init() override;

};
