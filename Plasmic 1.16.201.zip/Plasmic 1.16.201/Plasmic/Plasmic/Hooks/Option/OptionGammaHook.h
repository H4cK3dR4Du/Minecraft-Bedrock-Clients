#pragma once
#include "../../Module.h"

class OptionGammaHook : public Hook {
public:


	virtual void init() override;

};

