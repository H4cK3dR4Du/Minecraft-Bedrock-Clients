#pragma once
#include "../../Module.h"

class OptionSensivityHook : public Hook {
public:


	virtual void init() override;

};
