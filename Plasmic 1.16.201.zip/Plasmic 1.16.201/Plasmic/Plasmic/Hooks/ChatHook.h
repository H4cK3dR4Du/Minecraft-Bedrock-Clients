#pragma once
#include "../Module.h"

class ChatHook : public Hook {
public:
	virtual void init() override;

};

