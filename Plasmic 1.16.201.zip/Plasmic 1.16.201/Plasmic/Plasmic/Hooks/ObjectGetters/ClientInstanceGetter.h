#include "../../Module.h"


class ClientInstanceGetterHook : public Hook {

public:

	virtual void init() override;
};

