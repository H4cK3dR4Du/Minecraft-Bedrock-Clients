#pragma once
#include "../../Module.h"

class OnScreenChangedHook : public Hook {
public:
	virtual void init() override;
};

