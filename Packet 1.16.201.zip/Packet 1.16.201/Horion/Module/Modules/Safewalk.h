#pragma once

#include "Module.h"

class Safewalk : public IModule {
public: 
	Safewalk();
	virtual const char* getModuleName();

};