#pragma once
#include"DrawUtils.h"

class GuiUtils
{
public:
	static void drawCrossLine(vec2_t, MC_Color, float, float, bool) {};
	static void checkBox() {};
};

