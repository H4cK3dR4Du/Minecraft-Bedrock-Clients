﻿
namespace _Moon_V1_official.Arraylist
{
    partial class Arraylist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_targetstraffe = new System.Windows.Forms.Label();
            this.label_entitydisplay = new System.Windows.Forms.Label();
            this.label_kompass = new System.Windows.Forms.Label();
            this.label_aimbot = new System.Windows.Forms.Label();
            this.label_triggerbot = new System.Windows.Forms.Label();
            this.label_fakegamemode = new System.Windows.Forms.Label();
            this.label_scaffold = new System.Windows.Forms.Label();
            this.label_norender = new System.Windows.Forms.Label();
            this.label_antivoid = new System.Windows.Forms.Label();
            this.label_flydamagebypass = new System.Windows.Forms.Label();
            this.label_nofall = new System.Windows.Forms.Label();
            this.label_speedsneak = new System.Windows.Forms.Label();
            this.label_phase = new System.Windows.Forms.Label();
            this.label_airwalk = new System.Windows.Forms.Label();
            this.label_infinityjump = new System.Windows.Forms.Label();
            this.label_positionfreeze = new System.Windows.Forms.Label();
            this.label_glide = new System.Windows.Forms.Label();
            this.label_pglide = new System.Windows.Forms.Label();
            this.label_highjump = new System.Windows.Forms.Label();
            this.label_airjump = new System.Windows.Forms.Label();
            this.label_speed = new System.Windows.Forms.Label();
            this.label_stopvisualtime = new System.Windows.Forms.Label();
            this.label_fulllight = new System.Windows.Forms.Label();
            this.label_rainbowsky = new System.Windows.Forms.Label();
            this.label_zoom = new System.Windows.Forms.Label();
            this.label_infinityblockreach = new System.Windows.Forms.Label();
            this.label_Noknockback = new System.Windows.Forms.Label();
            this.label_instantbreak = new System.Windows.Forms.Label();
            this.label_Hitbox = new System.Windows.Forms.Label();
            this.label_reach = new System.Windows.Forms.Label();
            this.timer_aimbot = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label_targetstraffe);
            this.panel1.Controls.Add(this.label_entitydisplay);
            this.panel1.Controls.Add(this.label_kompass);
            this.panel1.Controls.Add(this.label_aimbot);
            this.panel1.Controls.Add(this.label_triggerbot);
            this.panel1.Controls.Add(this.label_fakegamemode);
            this.panel1.Controls.Add(this.label_scaffold);
            this.panel1.Controls.Add(this.label_norender);
            this.panel1.Controls.Add(this.label_antivoid);
            this.panel1.Controls.Add(this.label_flydamagebypass);
            this.panel1.Controls.Add(this.label_nofall);
            this.panel1.Controls.Add(this.label_speedsneak);
            this.panel1.Controls.Add(this.label_phase);
            this.panel1.Controls.Add(this.label_airwalk);
            this.panel1.Controls.Add(this.label_infinityjump);
            this.panel1.Controls.Add(this.label_positionfreeze);
            this.panel1.Controls.Add(this.label_glide);
            this.panel1.Controls.Add(this.label_pglide);
            this.panel1.Controls.Add(this.label_highjump);
            this.panel1.Controls.Add(this.label_airjump);
            this.panel1.Controls.Add(this.label_speed);
            this.panel1.Controls.Add(this.label_stopvisualtime);
            this.panel1.Controls.Add(this.label_fulllight);
            this.panel1.Controls.Add(this.label_rainbowsky);
            this.panel1.Controls.Add(this.label_zoom);
            this.panel1.Controls.Add(this.label_infinityblockreach);
            this.panel1.Controls.Add(this.label_Noknockback);
            this.panel1.Controls.Add(this.label_instantbreak);
            this.panel1.Controls.Add(this.label_Hitbox);
            this.panel1.Controls.Add(this.label_reach);
            this.panel1.Location = new System.Drawing.Point(2, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(298, 1019);
            this.panel1.TabIndex = 1;
            // 
            // label_targetstraffe
            // 
            this.label_targetstraffe.AutoSize = true;
            this.label_targetstraffe.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_targetstraffe.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_targetstraffe.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_targetstraffe.Location = new System.Drawing.Point(0, 899);
            this.label_targetstraffe.Name = "label_targetstraffe";
            this.label_targetstraffe.Size = new System.Drawing.Size(173, 31);
            this.label_targetstraffe.TabIndex = 30;
            this.label_targetstraffe.Text = "Targetstraffe";
            this.label_targetstraffe.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_targetstraffe.Visible = false;
            // 
            // label_entitydisplay
            // 
            this.label_entitydisplay.AutoSize = true;
            this.label_entitydisplay.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_entitydisplay.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_entitydisplay.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_entitydisplay.Location = new System.Drawing.Point(0, 868);
            this.label_entitydisplay.Name = "label_entitydisplay";
            this.label_entitydisplay.Size = new System.Drawing.Size(174, 31);
            this.label_entitydisplay.TabIndex = 29;
            this.label_entitydisplay.Text = "EntityDisplay";
            this.label_entitydisplay.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_entitydisplay.Visible = false;
            // 
            // label_kompass
            // 
            this.label_kompass.AutoSize = true;
            this.label_kompass.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_kompass.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_kompass.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_kompass.Location = new System.Drawing.Point(0, 837);
            this.label_kompass.Name = "label_kompass";
            this.label_kompass.Size = new System.Drawing.Size(124, 31);
            this.label_kompass.TabIndex = 27;
            this.label_kompass.Text = "Compass";
            this.label_kompass.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_kompass.Visible = false;
            // 
            // label_aimbot
            // 
            this.label_aimbot.AutoSize = true;
            this.label_aimbot.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_aimbot.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_aimbot.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_aimbot.Location = new System.Drawing.Point(0, 806);
            this.label_aimbot.Name = "label_aimbot";
            this.label_aimbot.Size = new System.Drawing.Size(105, 31);
            this.label_aimbot.TabIndex = 26;
            this.label_aimbot.Text = "Aimbot";
            this.label_aimbot.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_aimbot.Visible = false;
            // 
            // label_triggerbot
            // 
            this.label_triggerbot.AutoSize = true;
            this.label_triggerbot.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_triggerbot.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_triggerbot.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_triggerbot.Location = new System.Drawing.Point(0, 775);
            this.label_triggerbot.Name = "label_triggerbot";
            this.label_triggerbot.Size = new System.Drawing.Size(144, 31);
            this.label_triggerbot.TabIndex = 25;
            this.label_triggerbot.Text = "Triggerbot";
            this.label_triggerbot.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_triggerbot.Visible = false;
            // 
            // label_fakegamemode
            // 
            this.label_fakegamemode.AutoSize = true;
            this.label_fakegamemode.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_fakegamemode.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_fakegamemode.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_fakegamemode.Location = new System.Drawing.Point(0, 744);
            this.label_fakegamemode.Name = "label_fakegamemode";
            this.label_fakegamemode.Size = new System.Drawing.Size(209, 31);
            this.label_fakegamemode.TabIndex = 24;
            this.label_fakegamemode.Text = "FakeGamemode";
            this.label_fakegamemode.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_fakegamemode.Visible = false;
            // 
            // label_scaffold
            // 
            this.label_scaffold.AutoSize = true;
            this.label_scaffold.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_scaffold.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_scaffold.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_scaffold.Location = new System.Drawing.Point(0, 713);
            this.label_scaffold.Name = "label_scaffold";
            this.label_scaffold.Size = new System.Drawing.Size(113, 31);
            this.label_scaffold.TabIndex = 23;
            this.label_scaffold.Text = "Scaffold";
            this.label_scaffold.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_scaffold.Visible = false;
            // 
            // label_norender
            // 
            this.label_norender.AutoSize = true;
            this.label_norender.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_norender.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_norender.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_norender.Location = new System.Drawing.Point(0, 682);
            this.label_norender.Name = "label_norender";
            this.label_norender.Size = new System.Drawing.Size(137, 31);
            this.label_norender.TabIndex = 22;
            this.label_norender.Text = "NoRender";
            this.label_norender.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_norender.Visible = false;
            // 
            // label_antivoid
            // 
            this.label_antivoid.AutoSize = true;
            this.label_antivoid.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_antivoid.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_antivoid.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_antivoid.Location = new System.Drawing.Point(0, 651);
            this.label_antivoid.Name = "label_antivoid";
            this.label_antivoid.Size = new System.Drawing.Size(121, 31);
            this.label_antivoid.TabIndex = 21;
            this.label_antivoid.Text = "AntiVoid";
            this.label_antivoid.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_antivoid.Visible = false;
            // 
            // label_flydamagebypass
            // 
            this.label_flydamagebypass.AutoSize = true;
            this.label_flydamagebypass.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_flydamagebypass.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_flydamagebypass.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_flydamagebypass.Location = new System.Drawing.Point(0, 620);
            this.label_flydamagebypass.Name = "label_flydamagebypass";
            this.label_flydamagebypass.Size = new System.Drawing.Size(233, 31);
            this.label_flydamagebypass.TabIndex = 20;
            this.label_flydamagebypass.Text = "FlyDamageBypass";
            this.label_flydamagebypass.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_flydamagebypass.Visible = false;
            // 
            // label_nofall
            // 
            this.label_nofall.AutoSize = true;
            this.label_nofall.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_nofall.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nofall.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_nofall.Location = new System.Drawing.Point(0, 589);
            this.label_nofall.Name = "label_nofall";
            this.label_nofall.Size = new System.Drawing.Size(91, 31);
            this.label_nofall.TabIndex = 19;
            this.label_nofall.Text = "NoFall";
            this.label_nofall.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_nofall.Visible = false;
            // 
            // label_speedsneak
            // 
            this.label_speedsneak.AutoSize = true;
            this.label_speedsneak.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_speedsneak.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_speedsneak.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_speedsneak.Location = new System.Drawing.Point(0, 558);
            this.label_speedsneak.Name = "label_speedsneak";
            this.label_speedsneak.Size = new System.Drawing.Size(160, 31);
            this.label_speedsneak.TabIndex = 18;
            this.label_speedsneak.Text = "SpeedSneak";
            this.label_speedsneak.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_speedsneak.Visible = false;
            // 
            // label_phase
            // 
            this.label_phase.AutoSize = true;
            this.label_phase.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_phase.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_phase.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_phase.Location = new System.Drawing.Point(0, 527);
            this.label_phase.Name = "label_phase";
            this.label_phase.Size = new System.Drawing.Size(86, 31);
            this.label_phase.TabIndex = 17;
            this.label_phase.Text = "Phase";
            this.label_phase.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_phase.Visible = false;
            // 
            // label_airwalk
            // 
            this.label_airwalk.AutoSize = true;
            this.label_airwalk.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_airwalk.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_airwalk.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_airwalk.Location = new System.Drawing.Point(0, 496);
            this.label_airwalk.Name = "label_airwalk";
            this.label_airwalk.Size = new System.Drawing.Size(104, 31);
            this.label_airwalk.TabIndex = 16;
            this.label_airwalk.Text = "Airwalk";
            this.label_airwalk.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_airwalk.Visible = false;
            this.label_airwalk.Click += new System.EventHandler(this.label12_Click);
            // 
            // label_infinityjump
            // 
            this.label_infinityjump.AutoSize = true;
            this.label_infinityjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_infinityjump.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_infinityjump.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_infinityjump.Location = new System.Drawing.Point(0, 465);
            this.label_infinityjump.Name = "label_infinityjump";
            this.label_infinityjump.Size = new System.Drawing.Size(169, 31);
            this.label_infinityjump.TabIndex = 15;
            this.label_infinityjump.Text = "InfinityJump";
            this.label_infinityjump.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_infinityjump.Visible = false;
            // 
            // label_positionfreeze
            // 
            this.label_positionfreeze.AutoSize = true;
            this.label_positionfreeze.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_positionfreeze.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_positionfreeze.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_positionfreeze.Location = new System.Drawing.Point(0, 434);
            this.label_positionfreeze.Name = "label_positionfreeze";
            this.label_positionfreeze.Size = new System.Drawing.Size(188, 31);
            this.label_positionfreeze.TabIndex = 14;
            this.label_positionfreeze.Text = "Positionfreeze";
            this.label_positionfreeze.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_positionfreeze.Visible = false;
            // 
            // label_glide
            // 
            this.label_glide.AutoSize = true;
            this.label_glide.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_glide.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_glide.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_glide.Location = new System.Drawing.Point(0, 403);
            this.label_glide.Name = "label_glide";
            this.label_glide.Size = new System.Drawing.Size(76, 31);
            this.label_glide.TabIndex = 13;
            this.label_glide.Text = "Glide";
            this.label_glide.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_glide.Visible = false;
            // 
            // label_pglide
            // 
            this.label_pglide.AutoSize = true;
            this.label_pglide.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_pglide.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pglide.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_pglide.Location = new System.Drawing.Point(0, 372);
            this.label_pglide.Name = "label_pglide";
            this.label_pglide.Size = new System.Drawing.Size(92, 31);
            this.label_pglide.TabIndex = 12;
            this.label_pglide.Text = "PGlide";
            this.label_pglide.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_pglide.Visible = false;
            // 
            // label_highjump
            // 
            this.label_highjump.AutoSize = true;
            this.label_highjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_highjump.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_highjump.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_highjump.Location = new System.Drawing.Point(0, 341);
            this.label_highjump.Name = "label_highjump";
            this.label_highjump.Size = new System.Drawing.Size(140, 31);
            this.label_highjump.TabIndex = 11;
            this.label_highjump.Text = "HighJump";
            this.label_highjump.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_highjump.Visible = false;
            // 
            // label_airjump
            // 
            this.label_airjump.AutoSize = true;
            this.label_airjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_airjump.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_airjump.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_airjump.Location = new System.Drawing.Point(0, 310);
            this.label_airjump.Name = "label_airjump";
            this.label_airjump.Size = new System.Drawing.Size(112, 31);
            this.label_airjump.TabIndex = 10;
            this.label_airjump.Text = "Airjump";
            this.label_airjump.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_airjump.Visible = false;
            // 
            // label_speed
            // 
            this.label_speed.AutoSize = true;
            this.label_speed.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_speed.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_speed.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_speed.Location = new System.Drawing.Point(0, 279);
            this.label_speed.Name = "label_speed";
            this.label_speed.Size = new System.Drawing.Size(88, 31);
            this.label_speed.TabIndex = 9;
            this.label_speed.Text = "Speed";
            this.label_speed.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_speed.Visible = false;
            // 
            // label_stopvisualtime
            // 
            this.label_stopvisualtime.AutoSize = true;
            this.label_stopvisualtime.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_stopvisualtime.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_stopvisualtime.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_stopvisualtime.Location = new System.Drawing.Point(0, 248);
            this.label_stopvisualtime.Name = "label_stopvisualtime";
            this.label_stopvisualtime.Size = new System.Drawing.Size(203, 31);
            this.label_stopvisualtime.TabIndex = 8;
            this.label_stopvisualtime.Text = "StopVisualTime";
            this.label_stopvisualtime.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_stopvisualtime.Visible = false;
            // 
            // label_fulllight
            // 
            this.label_fulllight.AutoSize = true;
            this.label_fulllight.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_fulllight.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_fulllight.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_fulllight.Location = new System.Drawing.Point(0, 217);
            this.label_fulllight.Name = "label_fulllight";
            this.label_fulllight.Size = new System.Drawing.Size(113, 31);
            this.label_fulllight.TabIndex = 7;
            this.label_fulllight.Text = "Fulllight";
            this.label_fulllight.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_fulllight.Visible = false;
            // 
            // label_rainbowsky
            // 
            this.label_rainbowsky.AutoSize = true;
            this.label_rainbowsky.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_rainbowsky.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_rainbowsky.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_rainbowsky.Location = new System.Drawing.Point(0, 186);
            this.label_rainbowsky.Name = "label_rainbowsky";
            this.label_rainbowsky.Size = new System.Drawing.Size(160, 31);
            this.label_rainbowsky.TabIndex = 6;
            this.label_rainbowsky.Text = "Rainbowsky";
            this.label_rainbowsky.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_rainbowsky.Visible = false;
            // 
            // label_zoom
            // 
            this.label_zoom.AutoSize = true;
            this.label_zoom.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_zoom.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_zoom.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_zoom.Location = new System.Drawing.Point(0, 155);
            this.label_zoom.Name = "label_zoom";
            this.label_zoom.Size = new System.Drawing.Size(86, 31);
            this.label_zoom.TabIndex = 5;
            this.label_zoom.Text = "Zoom";
            this.label_zoom.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_zoom.Visible = false;
            // 
            // label_infinityblockreach
            // 
            this.label_infinityblockreach.AutoSize = true;
            this.label_infinityblockreach.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_infinityblockreach.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_infinityblockreach.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_infinityblockreach.Location = new System.Drawing.Point(0, 124);
            this.label_infinityblockreach.Name = "label_infinityblockreach";
            this.label_infinityblockreach.Size = new System.Drawing.Size(240, 31);
            this.label_infinityblockreach.TabIndex = 4;
            this.label_infinityblockreach.Text = "InfinityBlockReach";
            this.label_infinityblockreach.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_infinityblockreach.Visible = false;
            // 
            // label_Noknockback
            // 
            this.label_Noknockback.AutoSize = true;
            this.label_Noknockback.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_Noknockback.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Noknockback.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_Noknockback.Location = new System.Drawing.Point(0, 93);
            this.label_Noknockback.Name = "label_Noknockback";
            this.label_Noknockback.Size = new System.Drawing.Size(181, 31);
            this.label_Noknockback.TabIndex = 3;
            this.label_Noknockback.Text = "NoKnockback";
            this.label_Noknockback.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_Noknockback.Visible = false;
            // 
            // label_instantbreak
            // 
            this.label_instantbreak.AutoSize = true;
            this.label_instantbreak.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_instantbreak.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_instantbreak.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_instantbreak.Location = new System.Drawing.Point(0, 62);
            this.label_instantbreak.Name = "label_instantbreak";
            this.label_instantbreak.Size = new System.Drawing.Size(168, 31);
            this.label_instantbreak.TabIndex = 2;
            this.label_instantbreak.Text = "Instantbreak";
            this.label_instantbreak.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label_instantbreak.Visible = false;
            // 
            // label_Hitbox
            // 
            this.label_Hitbox.AutoSize = true;
            this.label_Hitbox.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_Hitbox.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Hitbox.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_Hitbox.Location = new System.Drawing.Point(0, 31);
            this.label_Hitbox.Name = "label_Hitbox";
            this.label_Hitbox.Size = new System.Drawing.Size(97, 31);
            this.label_Hitbox.TabIndex = 1;
            this.label_Hitbox.Text = "Hitbox";
            this.label_Hitbox.Visible = false;
            // 
            // label_reach
            // 
            this.label_reach.AutoSize = true;
            this.label_reach.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_reach.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_reach.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_reach.Location = new System.Drawing.Point(0, 0);
            this.label_reach.Name = "label_reach";
            this.label_reach.Size = new System.Drawing.Size(87, 31);
            this.label_reach.TabIndex = 0;
            this.label_reach.Text = "Reach";
            this.label_reach.Visible = false;
            this.label_reach.Click += new System.EventHandler(this.label_reach_Click);
            // 
            // timer_aimbot
            // 
            this.timer_aimbot.Interval = 10;
            this.timer_aimbot.Tick += new System.EventHandler(this.timer_aimbot_Tick);
            // 
            // Arraylist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1890, 1100);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Arraylist";
            this.Text = "Arraylist";
            this.Load += new System.EventHandler(this.Arraylist_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label label_instantbreak;
        public System.Windows.Forms.Label label_Hitbox;
        public System.Windows.Forms.Label label_reach;
        public System.Windows.Forms.Label label_Noknockback;
        public System.Windows.Forms.Label label_infinityblockreach;
        public System.Windows.Forms.Label label_zoom;
        public System.Windows.Forms.Label label_stopvisualtime;
        public System.Windows.Forms.Label label_fulllight;
        public System.Windows.Forms.Label label_rainbowsky;
        public System.Windows.Forms.Label label_highjump;
        public System.Windows.Forms.Label label_airjump;
        public System.Windows.Forms.Label label_speed;
        public System.Windows.Forms.Label label_pglide;
        public System.Windows.Forms.Label label_glide;
        public System.Windows.Forms.Label label_positionfreeze;
        public System.Windows.Forms.Label label_airwalk;
        public System.Windows.Forms.Label label_infinityjump;
        public System.Windows.Forms.Label label_speedsneak;
        public System.Windows.Forms.Label label_phase;
        public System.Windows.Forms.Label label_flydamagebypass;
        public System.Windows.Forms.Label label_nofall;
        public System.Windows.Forms.Label label_antivoid;
        public System.Windows.Forms.Label label_fakegamemode;
        public System.Windows.Forms.Label label_scaffold;
        public System.Windows.Forms.Label label_norender;
        public System.Windows.Forms.Label label_triggerbot;
        public System.Windows.Forms.Label label_kompass;
        public System.Windows.Forms.Label label_aimbot;
        public System.Windows.Forms.Label label_entitydisplay;
        public System.Windows.Forms.Label label_targetstraffe;
        private System.Windows.Forms.Timer timer_aimbot;
    }
}