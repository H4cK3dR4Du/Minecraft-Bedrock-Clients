﻿
namespace _Moon_V1_official
{
    public partial class ClickGui
    {

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_combo = new System.Windows.Forms.Panel();
            this.panel_aimbot = new System.Windows.Forms.Panel();
            this.button_aimbot_h = new System.Windows.Forms.Button();
            this.button_aimbot = new System.Windows.Forms.Button();
            this.panel_triggerbot = new System.Windows.Forms.Panel();
            this.button_triggerbot_hotkey = new System.Windows.Forms.Button();
            this.button_triggerbot = new System.Windows.Forms.Button();
            this.panel_AutoClicker = new System.Windows.Forms.Panel();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.button_AutoClicker_hotkey = new System.Windows.Forms.Button();
            this.button_AutoClicker = new System.Windows.Forms.Button();
            this.panel_Infinityblockreach = new System.Windows.Forms.Panel();
            this.textBox_Infinityblockreach = new System.Windows.Forms.TextBox();
            this.button_Infinityblockreach_hotkey = new System.Windows.Forms.Button();
            this.button_Infinityblockreach = new System.Windows.Forms.Button();
            this.panel_noknockback = new System.Windows.Forms.Panel();
            this.button_noknockback_hotkey = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel_instantbreak = new System.Windows.Forms.Panel();
            this.button_instantbreak_hotkey = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel_hitbox = new System.Windows.Forms.Panel();
            this.trackBar_hitbox_withe = new System.Windows.Forms.TrackBar();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.trackBar_hitbox_high = new System.Windows.Forms.TrackBar();
            this.button_hitbox_hotkey = new System.Windows.Forms.Button();
            this.button_hitbox = new System.Windows.Forms.Button();
            this.panel_reach = new System.Windows.Forms.Panel();
            this.trackBar_reach = new System.Windows.Forms.TrackBar();
            this.button_reach_hotkey = new System.Windows.Forms.Button();
            this.button_reach = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_visuals = new System.Windows.Forms.Panel();
            this.panel_kompass = new System.Windows.Forms.Panel();
            this.button_kompass_h = new System.Windows.Forms.Button();
            this.button_kompass = new System.Windows.Forms.Button();
            this.panel_entitydisplay = new System.Windows.Forms.Panel();
            this.button_entitydisplay_h = new System.Windows.Forms.Button();
            this.button_entitydisplay = new System.Windows.Forms.Button();
            this.panel_StopVisualTime = new System.Windows.Forms.Panel();
            this.button_stopvisualtime_h = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel_fulllight = new System.Windows.Forms.Panel();
            this.button_fulllight_h = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.panel_rainbowsky = new System.Windows.Forms.Panel();
            this.button_rainbowsky_h = new System.Windows.Forms.Button();
            this.button_rainbowsky = new System.Windows.Forms.Button();
            this.panel_zoom = new System.Windows.Forms.Panel();
            this.button_zoom_h = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_speedsneak = new System.Windows.Forms.Panel();
            this.button_speedsneak_h = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.panel_phase = new System.Windows.Forms.Panel();
            this.button_phase_h = new System.Windows.Forms.Button();
            this.button_phase = new System.Windows.Forms.Button();
            this.panel_airwalk = new System.Windows.Forms.Panel();
            this.button_airwalk_h = new System.Windows.Forms.Button();
            this.button_airwalk = new System.Windows.Forms.Button();
            this.panel_infinityjump = new System.Windows.Forms.Panel();
            this.button_infinijump_h = new System.Windows.Forms.Button();
            this.button_infinityjump = new System.Windows.Forms.Button();
            this.panel_positionfreeze = new System.Windows.Forms.Panel();
            this.button_positionfreeze_h = new System.Windows.Forms.Button();
            this.button_positionfreeze = new System.Windows.Forms.Button();
            this.panel_glide = new System.Windows.Forms.Panel();
            this.button_glide_h = new System.Windows.Forms.Button();
            this.button_glide = new System.Windows.Forms.Button();
            this.panel_pglide = new System.Windows.Forms.Panel();
            this.button_pglide_h = new System.Windows.Forms.Button();
            this.button_pglide = new System.Windows.Forms.Button();
            this.panel_highjump = new System.Windows.Forms.Panel();
            this.button_highjump_h = new System.Windows.Forms.Button();
            this.button_highjump = new System.Windows.Forms.Button();
            this.panel_airjump = new System.Windows.Forms.Panel();
            this.button_airjump_h = new System.Windows.Forms.Button();
            this.button_airjump = new System.Windows.Forms.Button();
            this.panel_speed = new System.Windows.Forms.Panel();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.button_speed_h = new System.Windows.Forms.Button();
            this.button_speed = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_exploits = new System.Windows.Forms.Panel();
            this.panel_targetstraffe = new System.Windows.Forms.Panel();
            this.button_targetstraffe_h = new System.Windows.Forms.Button();
            this.button_tragtetstraffe = new System.Windows.Forms.Button();
            this.panel_fakegamemode = new System.Windows.Forms.Panel();
            this.button_fakegamemode_h = new System.Windows.Forms.Button();
            this.button_fakegamemode = new System.Windows.Forms.Button();
            this.panel_scaffold = new System.Windows.Forms.Panel();
            this.button_scaffold_h = new System.Windows.Forms.Button();
            this.button_scaffold = new System.Windows.Forms.Button();
            this.panel_norender = new System.Windows.Forms.Panel();
            this.button_norender_h = new System.Windows.Forms.Button();
            this.button_norender = new System.Windows.Forms.Button();
            this.panel_antivoid = new System.Windows.Forms.Panel();
            this.button_antivoid_h = new System.Windows.Forms.Button();
            this.button_antivoid = new System.Windows.Forms.Button();
            this.panel_FlyDamageBypass = new System.Windows.Forms.Panel();
            this.button_flydamagebypass_h = new System.Windows.Forms.Button();
            this.button_FlyDamageBypass = new System.Windows.Forms.Button();
            this.panel_nofall = new System.Windows.Forms.Panel();
            this.button_nofall_h = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel_settings = new System.Windows.Forms.Panel();
            this.panel_watermark = new System.Windows.Forms.Panel();
            this.button_watermark_h = new System.Windows.Forms.Button();
            this.button_watermark = new System.Windows.Forms.Button();
            this.panel_arraylist = new System.Windows.Forms.Panel();
            this.button_arraylist_h = new System.Windows.Forms.Button();
            this.button_arraylist = new System.Windows.Forms.Button();
            this.panel_tabgui = new System.Windows.Forms.Panel();
            this.button_tabgui_h = new System.Windows.Forms.Button();
            this.button_tabgui = new System.Windows.Forms.Button();
            this.panel_clickgui = new System.Windows.Forms.Panel();
            this.button_clickgui_hotkey = new System.Windows.Forms.Button();
            this.button_clickgui = new System.Windows.Forms.Button();
            this.panel_keystrokes = new System.Windows.Forms.Panel();
            this.button_keystrokes_h = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.timer_aimbot = new System.Windows.Forms.Timer(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.panel_combo.SuspendLayout();
            this.panel_aimbot.SuspendLayout();
            this.panel_triggerbot.SuspendLayout();
            this.panel_AutoClicker.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.panel_Infinityblockreach.SuspendLayout();
            this.panel_noknockback.SuspendLayout();
            this.panel_instantbreak.SuspendLayout();
            this.panel_hitbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_hitbox_withe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_hitbox_high)).BeginInit();
            this.panel_reach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_reach)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel_visuals.SuspendLayout();
            this.panel_kompass.SuspendLayout();
            this.panel_entitydisplay.SuspendLayout();
            this.panel_StopVisualTime.SuspendLayout();
            this.panel_fulllight.SuspendLayout();
            this.panel_rainbowsky.SuspendLayout();
            this.panel_zoom.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel_speedsneak.SuspendLayout();
            this.panel_phase.SuspendLayout();
            this.panel_airwalk.SuspendLayout();
            this.panel_infinityjump.SuspendLayout();
            this.panel_positionfreeze.SuspendLayout();
            this.panel_glide.SuspendLayout();
            this.panel_pglide.SuspendLayout();
            this.panel_highjump.SuspendLayout();
            this.panel_airjump.SuspendLayout();
            this.panel_speed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel_exploits.SuspendLayout();
            this.panel_targetstraffe.SuspendLayout();
            this.panel_fakegamemode.SuspendLayout();
            this.panel_scaffold.SuspendLayout();
            this.panel_norender.SuspendLayout();
            this.panel_antivoid.SuspendLayout();
            this.panel_FlyDamageBypass.SuspendLayout();
            this.panel_nofall.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel_settings.SuspendLayout();
            this.panel_watermark.SuspendLayout();
            this.panel_arraylist.SuspendLayout();
            this.panel_tabgui.SuspendLayout();
            this.panel_clickgui.SuspendLayout();
            this.panel_keystrokes.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_combo
            // 
            this.panel_combo.AutoScroll = true;
            this.panel_combo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.panel_combo.Controls.Add(this.panel_aimbot);
            this.panel_combo.Controls.Add(this.button_aimbot);
            this.panel_combo.Controls.Add(this.panel_triggerbot);
            this.panel_combo.Controls.Add(this.button_triggerbot);
            this.panel_combo.Controls.Add(this.panel_AutoClicker);
            this.panel_combo.Controls.Add(this.button_AutoClicker);
            this.panel_combo.Controls.Add(this.panel_Infinityblockreach);
            this.panel_combo.Controls.Add(this.button_Infinityblockreach);
            this.panel_combo.Controls.Add(this.panel_noknockback);
            this.panel_combo.Controls.Add(this.button4);
            this.panel_combo.Controls.Add(this.panel_instantbreak);
            this.panel_combo.Controls.Add(this.button2);
            this.panel_combo.Controls.Add(this.panel_hitbox);
            this.panel_combo.Controls.Add(this.button_hitbox);
            this.panel_combo.Controls.Add(this.panel_reach);
            this.panel_combo.Controls.Add(this.button_reach);
            this.panel_combo.Controls.Add(this.panel2);
            this.panel_combo.Location = new System.Drawing.Point(120, 42);
            this.panel_combo.Name = "panel_combo";
            this.panel_combo.Size = new System.Drawing.Size(182, 353);
            this.panel_combo.TabIndex = 0;
            // 
            // panel_aimbot
            // 
            this.panel_aimbot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_aimbot.Controls.Add(this.button_aimbot_h);
            this.panel_aimbot.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_aimbot.Location = new System.Drawing.Point(0, 958);
            this.panel_aimbot.Name = "panel_aimbot";
            this.panel_aimbot.Size = new System.Drawing.Size(165, 54);
            this.panel_aimbot.TabIndex = 16;
            this.panel_aimbot.Visible = false;
            // 
            // button_aimbot_h
            // 
            this.button_aimbot_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_aimbot_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_aimbot_h.FlatAppearance.BorderSize = 0;
            this.button_aimbot_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_aimbot_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_aimbot_h.Location = new System.Drawing.Point(0, 0);
            this.button_aimbot_h.Name = "button_aimbot_h";
            this.button_aimbot_h.Size = new System.Drawing.Size(165, 38);
            this.button_aimbot_h.TabIndex = 2;
            this.button_aimbot_h.Text = "Hotkey:";
            this.button_aimbot_h.UseVisualStyleBackColor = false;
            this.button_aimbot_h.Click += new System.EventHandler(this.button_aimbot_h_Click);
            // 
            // button_aimbot
            // 
            this.button_aimbot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_aimbot.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_aimbot.FlatAppearance.BorderSize = 0;
            this.button_aimbot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_aimbot.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_aimbot.Location = new System.Drawing.Point(0, 912);
            this.button_aimbot.Name = "button_aimbot";
            this.button_aimbot.Size = new System.Drawing.Size(165, 46);
            this.button_aimbot.TabIndex = 15;
            this.button_aimbot.Text = "Aimbot";
            this.button_aimbot.UseVisualStyleBackColor = false;
            this.button_aimbot.Click += new System.EventHandler(this.button_aimbot_Click);
            // 
            // panel_triggerbot
            // 
            this.panel_triggerbot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_triggerbot.Controls.Add(this.button_triggerbot_hotkey);
            this.panel_triggerbot.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_triggerbot.Location = new System.Drawing.Point(0, 862);
            this.panel_triggerbot.Name = "panel_triggerbot";
            this.panel_triggerbot.Size = new System.Drawing.Size(165, 50);
            this.panel_triggerbot.TabIndex = 14;
            this.panel_triggerbot.Visible = false;
            // 
            // button_triggerbot_hotkey
            // 
            this.button_triggerbot_hotkey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_triggerbot_hotkey.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_triggerbot_hotkey.FlatAppearance.BorderSize = 0;
            this.button_triggerbot_hotkey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_triggerbot_hotkey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_triggerbot_hotkey.Location = new System.Drawing.Point(0, 0);
            this.button_triggerbot_hotkey.Name = "button_triggerbot_hotkey";
            this.button_triggerbot_hotkey.Size = new System.Drawing.Size(165, 44);
            this.button_triggerbot_hotkey.TabIndex = 2;
            this.button_triggerbot_hotkey.Text = "Hotkey:";
            this.button_triggerbot_hotkey.UseVisualStyleBackColor = false;
            this.button_triggerbot_hotkey.Click += new System.EventHandler(this.button_triggerbot_hotkey_Click);
            // 
            // button_triggerbot
            // 
            this.button_triggerbot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_triggerbot.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_triggerbot.FlatAppearance.BorderSize = 0;
            this.button_triggerbot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_triggerbot.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_triggerbot.Location = new System.Drawing.Point(0, 816);
            this.button_triggerbot.Name = "button_triggerbot";
            this.button_triggerbot.Size = new System.Drawing.Size(165, 46);
            this.button_triggerbot.TabIndex = 13;
            this.button_triggerbot.Text = "Triggerbot";
            this.button_triggerbot.UseVisualStyleBackColor = false;
            this.button_triggerbot.Click += new System.EventHandler(this.button_triggerbot_Click);
            // 
            // panel_AutoClicker
            // 
            this.panel_AutoClicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_AutoClicker.Controls.Add(this.trackBar2);
            this.panel_AutoClicker.Controls.Add(this.checkBox2);
            this.panel_AutoClicker.Controls.Add(this.checkBox1);
            this.panel_AutoClicker.Controls.Add(this.trackBar1);
            this.panel_AutoClicker.Controls.Add(this.button_AutoClicker_hotkey);
            this.panel_AutoClicker.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_AutoClicker.Location = new System.Drawing.Point(0, 713);
            this.panel_AutoClicker.Name = "panel_AutoClicker";
            this.panel_AutoClicker.Size = new System.Drawing.Size(165, 103);
            this.panel_AutoClicker.TabIndex = 12;
            this.panel_AutoClicker.Visible = false;
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(0, 136);
            this.trackBar2.Maximum = 7;
            this.trackBar2.Minimum = 1;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(194, 45);
            this.trackBar2.TabIndex = 7;
            this.trackBar2.Value = 1;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(15, 118);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(51, 17);
            this.checkBox2.TabIndex = 6;
            this.checkBox2.Text = "Right";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(15, 44);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(44, 17);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "Left";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(3, 67);
            this.trackBar1.Maximum = 7;
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(194, 45);
            this.trackBar1.TabIndex = 4;
            this.trackBar1.Value = 1;
            // 
            // button_AutoClicker_hotkey
            // 
            this.button_AutoClicker_hotkey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_AutoClicker_hotkey.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_AutoClicker_hotkey.FlatAppearance.BorderSize = 0;
            this.button_AutoClicker_hotkey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_AutoClicker_hotkey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_AutoClicker_hotkey.Location = new System.Drawing.Point(0, 0);
            this.button_AutoClicker_hotkey.Name = "button_AutoClicker_hotkey";
            this.button_AutoClicker_hotkey.Size = new System.Drawing.Size(165, 10);
            this.button_AutoClicker_hotkey.TabIndex = 2;
            this.button_AutoClicker_hotkey.Text = "Hotkey:";
            this.button_AutoClicker_hotkey.UseVisualStyleBackColor = false;
            // 
            // button_AutoClicker
            // 
            this.button_AutoClicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_AutoClicker.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_AutoClicker.FlatAppearance.BorderSize = 0;
            this.button_AutoClicker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_AutoClicker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_AutoClicker.Location = new System.Drawing.Point(0, 703);
            this.button_AutoClicker.Name = "button_AutoClicker";
            this.button_AutoClicker.Size = new System.Drawing.Size(165, 10);
            this.button_AutoClicker.TabIndex = 11;
            this.button_AutoClicker.Text = "AutoClicker";
            this.button_AutoClicker.UseVisualStyleBackColor = false;
            this.button_AutoClicker.Click += new System.EventHandler(this.button_AutoClicker_Click);
            // 
            // panel_Infinityblockreach
            // 
            this.panel_Infinityblockreach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_Infinityblockreach.Controls.Add(this.textBox_Infinityblockreach);
            this.panel_Infinityblockreach.Controls.Add(this.button_Infinityblockreach_hotkey);
            this.panel_Infinityblockreach.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Infinityblockreach.Location = new System.Drawing.Point(0, 629);
            this.panel_Infinityblockreach.Name = "panel_Infinityblockreach";
            this.panel_Infinityblockreach.Size = new System.Drawing.Size(165, 74);
            this.panel_Infinityblockreach.TabIndex = 10;
            this.panel_Infinityblockreach.Visible = false;
            // 
            // textBox_Infinityblockreach
            // 
            this.textBox_Infinityblockreach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(181)))), ((int)(((byte)(189)))));
            this.textBox_Infinityblockreach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_Infinityblockreach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Infinityblockreach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.textBox_Infinityblockreach.Location = new System.Drawing.Point(3, 44);
            this.textBox_Infinityblockreach.Name = "textBox_Infinityblockreach";
            this.textBox_Infinityblockreach.Size = new System.Drawing.Size(194, 19);
            this.textBox_Infinityblockreach.TabIndex = 3;
            this.textBox_Infinityblockreach.Text = "999";
            this.textBox_Infinityblockreach.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_Infinityblockreach_hotkey
            // 
            this.button_Infinityblockreach_hotkey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_Infinityblockreach_hotkey.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Infinityblockreach_hotkey.FlatAppearance.BorderSize = 0;
            this.button_Infinityblockreach_hotkey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Infinityblockreach_hotkey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_Infinityblockreach_hotkey.Location = new System.Drawing.Point(0, 0);
            this.button_Infinityblockreach_hotkey.Name = "button_Infinityblockreach_hotkey";
            this.button_Infinityblockreach_hotkey.Size = new System.Drawing.Size(165, 38);
            this.button_Infinityblockreach_hotkey.TabIndex = 2;
            this.button_Infinityblockreach_hotkey.Text = "Hotkey:";
            this.button_Infinityblockreach_hotkey.UseVisualStyleBackColor = false;
            this.button_Infinityblockreach_hotkey.Click += new System.EventHandler(this.button_Infinityblockreach_hotkey_Click);
            // 
            // button_Infinityblockreach
            // 
            this.button_Infinityblockreach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_Infinityblockreach.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_Infinityblockreach.FlatAppearance.BorderSize = 0;
            this.button_Infinityblockreach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Infinityblockreach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_Infinityblockreach.Location = new System.Drawing.Point(0, 583);
            this.button_Infinityblockreach.Name = "button_Infinityblockreach";
            this.button_Infinityblockreach.Size = new System.Drawing.Size(165, 46);
            this.button_Infinityblockreach.TabIndex = 9;
            this.button_Infinityblockreach.Text = "Infinityblockreach";
            this.button_Infinityblockreach.UseVisualStyleBackColor = false;
            this.button_Infinityblockreach.Click += new System.EventHandler(this.button_Infinityblockreach_Click);
            // 
            // panel_noknockback
            // 
            this.panel_noknockback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_noknockback.Controls.Add(this.button_noknockback_hotkey);
            this.panel_noknockback.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_noknockback.Location = new System.Drawing.Point(0, 545);
            this.panel_noknockback.Name = "panel_noknockback";
            this.panel_noknockback.Size = new System.Drawing.Size(165, 38);
            this.panel_noknockback.TabIndex = 8;
            this.panel_noknockback.Visible = false;
            // 
            // button_noknockback_hotkey
            // 
            this.button_noknockback_hotkey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_noknockback_hotkey.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_noknockback_hotkey.FlatAppearance.BorderSize = 0;
            this.button_noknockback_hotkey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_noknockback_hotkey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_noknockback_hotkey.Location = new System.Drawing.Point(0, 0);
            this.button_noknockback_hotkey.Name = "button_noknockback_hotkey";
            this.button_noknockback_hotkey.Size = new System.Drawing.Size(165, 38);
            this.button_noknockback_hotkey.TabIndex = 2;
            this.button_noknockback_hotkey.Text = "Hotkey:";
            this.button_noknockback_hotkey.UseVisualStyleBackColor = false;
            this.button_noknockback_hotkey.Click += new System.EventHandler(this.button_noknockback_hotkey_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button4.Location = new System.Drawing.Point(0, 499);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(165, 46);
            this.button4.TabIndex = 7;
            this.button4.Text = "NoKnockback";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel_instantbreak
            // 
            this.panel_instantbreak.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_instantbreak.Controls.Add(this.button_instantbreak_hotkey);
            this.panel_instantbreak.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_instantbreak.Location = new System.Drawing.Point(0, 460);
            this.panel_instantbreak.Name = "panel_instantbreak";
            this.panel_instantbreak.Size = new System.Drawing.Size(165, 39);
            this.panel_instantbreak.TabIndex = 6;
            this.panel_instantbreak.Visible = false;
            // 
            // button_instantbreak_hotkey
            // 
            this.button_instantbreak_hotkey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_instantbreak_hotkey.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_instantbreak_hotkey.FlatAppearance.BorderSize = 0;
            this.button_instantbreak_hotkey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_instantbreak_hotkey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_instantbreak_hotkey.Location = new System.Drawing.Point(0, 0);
            this.button_instantbreak_hotkey.Name = "button_instantbreak_hotkey";
            this.button_instantbreak_hotkey.Size = new System.Drawing.Size(165, 39);
            this.button_instantbreak_hotkey.TabIndex = 2;
            this.button_instantbreak_hotkey.Text = "Hotkey:";
            this.button_instantbreak_hotkey.UseVisualStyleBackColor = false;
            this.button_instantbreak_hotkey.Click += new System.EventHandler(this.button_instantbreak_hotkey_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button2.Location = new System.Drawing.Point(0, 414);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(165, 46);
            this.button2.TabIndex = 5;
            this.button2.Text = "Instantbreak";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel_hitbox
            // 
            this.panel_hitbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_hitbox.Controls.Add(this.trackBar_hitbox_withe);
            this.panel_hitbox.Controls.Add(this.label7);
            this.panel_hitbox.Controls.Add(this.label6);
            this.panel_hitbox.Controls.Add(this.trackBar_hitbox_high);
            this.panel_hitbox.Controls.Add(this.button_hitbox_hotkey);
            this.panel_hitbox.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_hitbox.Location = new System.Drawing.Point(0, 235);
            this.panel_hitbox.Name = "panel_hitbox";
            this.panel_hitbox.Size = new System.Drawing.Size(165, 179);
            this.panel_hitbox.TabIndex = 4;
            this.panel_hitbox.Visible = false;
            // 
            // trackBar_hitbox_withe
            // 
            this.trackBar_hitbox_withe.Location = new System.Drawing.Point(3, 120);
            this.trackBar_hitbox_withe.Maximum = 7;
            this.trackBar_hitbox_withe.Minimum = 1;
            this.trackBar_hitbox_withe.Name = "trackBar_hitbox_withe";
            this.trackBar_hitbox_withe.Size = new System.Drawing.Size(162, 45);
            this.trackBar_hitbox_withe.TabIndex = 6;
            this.trackBar_hitbox_withe.Value = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Withe";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "High";
            // 
            // trackBar_hitbox_high
            // 
            this.trackBar_hitbox_high.Location = new System.Drawing.Point(3, 60);
            this.trackBar_hitbox_high.Maximum = 7;
            this.trackBar_hitbox_high.Minimum = 1;
            this.trackBar_hitbox_high.Name = "trackBar_hitbox_high";
            this.trackBar_hitbox_high.Size = new System.Drawing.Size(162, 45);
            this.trackBar_hitbox_high.TabIndex = 3;
            this.trackBar_hitbox_high.Value = 1;
            // 
            // button_hitbox_hotkey
            // 
            this.button_hitbox_hotkey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_hitbox_hotkey.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_hitbox_hotkey.FlatAppearance.BorderSize = 0;
            this.button_hitbox_hotkey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_hitbox_hotkey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_hitbox_hotkey.Location = new System.Drawing.Point(0, 0);
            this.button_hitbox_hotkey.Name = "button_hitbox_hotkey";
            this.button_hitbox_hotkey.Size = new System.Drawing.Size(165, 38);
            this.button_hitbox_hotkey.TabIndex = 2;
            this.button_hitbox_hotkey.Text = "Hotkey:";
            this.button_hitbox_hotkey.UseVisualStyleBackColor = false;
            this.button_hitbox_hotkey.Click += new System.EventHandler(this.button_hitbox_hotkey_Click);
            // 
            // button_hitbox
            // 
            this.button_hitbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_hitbox.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_hitbox.FlatAppearance.BorderSize = 0;
            this.button_hitbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_hitbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_hitbox.Location = new System.Drawing.Point(0, 189);
            this.button_hitbox.Name = "button_hitbox";
            this.button_hitbox.Size = new System.Drawing.Size(165, 46);
            this.button_hitbox.TabIndex = 3;
            this.button_hitbox.Text = "Hitbox";
            this.button_hitbox.UseVisualStyleBackColor = false;
            this.button_hitbox.Click += new System.EventHandler(this.button_hitbox_Click);
            // 
            // panel_reach
            // 
            this.panel_reach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_reach.Controls.Add(this.trackBar_reach);
            this.panel_reach.Controls.Add(this.button_reach_hotkey);
            this.panel_reach.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_reach.Location = new System.Drawing.Point(0, 89);
            this.panel_reach.Name = "panel_reach";
            this.panel_reach.Size = new System.Drawing.Size(165, 100);
            this.panel_reach.TabIndex = 2;
            this.panel_reach.Visible = false;
            // 
            // trackBar_reach
            // 
            this.trackBar_reach.Location = new System.Drawing.Point(3, 44);
            this.trackBar_reach.Maximum = 7;
            this.trackBar_reach.Minimum = 1;
            this.trackBar_reach.Name = "trackBar_reach";
            this.trackBar_reach.Size = new System.Drawing.Size(159, 45);
            this.trackBar_reach.TabIndex = 3;
            this.trackBar_reach.Value = 7;
            this.trackBar_reach.Scroll += new System.EventHandler(this.trackBar_reach_Scroll);
            // 
            // button_reach_hotkey
            // 
            this.button_reach_hotkey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_reach_hotkey.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_reach_hotkey.FlatAppearance.BorderSize = 0;
            this.button_reach_hotkey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reach_hotkey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_reach_hotkey.Location = new System.Drawing.Point(0, 0);
            this.button_reach_hotkey.Name = "button_reach_hotkey";
            this.button_reach_hotkey.Size = new System.Drawing.Size(165, 38);
            this.button_reach_hotkey.TabIndex = 2;
            this.button_reach_hotkey.Text = "Hotkey:";
            this.button_reach_hotkey.UseVisualStyleBackColor = false;
            this.button_reach_hotkey.Click += new System.EventHandler(this.button_reach_hotkey_Click);
            // 
            // button_reach
            // 
            this.button_reach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_reach.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_reach.FlatAppearance.BorderSize = 0;
            this.button_reach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_reach.Location = new System.Drawing.Point(0, 43);
            this.button_reach.Name = "button_reach";
            this.button_reach.Size = new System.Drawing.Size(165, 46);
            this.button_reach.TabIndex = 1;
            this.button_reach.Text = "Reach";
            this.button_reach.UseVisualStyleBackColor = false;
            this.button_reach.Click += new System.EventHandler(this.button_reach_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(165, 43);
            this.panel2.TabIndex = 0;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseMove);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.label1.Location = new System.Drawing.Point(48, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Combo";
            // 
            // panel_visuals
            // 
            this.panel_visuals.AutoScroll = true;
            this.panel_visuals.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.panel_visuals.Controls.Add(this.panel_kompass);
            this.panel_visuals.Controls.Add(this.button_kompass);
            this.panel_visuals.Controls.Add(this.panel_entitydisplay);
            this.panel_visuals.Controls.Add(this.button_entitydisplay);
            this.panel_visuals.Controls.Add(this.panel_StopVisualTime);
            this.panel_visuals.Controls.Add(this.button18);
            this.panel_visuals.Controls.Add(this.panel_fulllight);
            this.panel_visuals.Controls.Add(this.button16);
            this.panel_visuals.Controls.Add(this.panel_rainbowsky);
            this.panel_visuals.Controls.Add(this.button_rainbowsky);
            this.panel_visuals.Controls.Add(this.panel_zoom);
            this.panel_visuals.Controls.Add(this.button13);
            this.panel_visuals.Controls.Add(this.panel3);
            this.panel_visuals.Location = new System.Drawing.Point(323, 42);
            this.panel_visuals.Name = "panel_visuals";
            this.panel_visuals.Size = new System.Drawing.Size(165, 281);
            this.panel_visuals.TabIndex = 1;
            // 
            // panel_kompass
            // 
            this.panel_kompass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_kompass.Controls.Add(this.button_kompass_h);
            this.panel_kompass.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_kompass.Location = new System.Drawing.Point(0, 564);
            this.panel_kompass.Name = "panel_kompass";
            this.panel_kompass.Size = new System.Drawing.Size(148, 49);
            this.panel_kompass.TabIndex = 14;
            this.panel_kompass.Visible = false;
            // 
            // button_kompass_h
            // 
            this.button_kompass_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_kompass_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_kompass_h.FlatAppearance.BorderSize = 0;
            this.button_kompass_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_kompass_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_kompass_h.Location = new System.Drawing.Point(0, 0);
            this.button_kompass_h.Name = "button_kompass_h";
            this.button_kompass_h.Size = new System.Drawing.Size(148, 38);
            this.button_kompass_h.TabIndex = 2;
            this.button_kompass_h.Text = "Hotkey:";
            this.button_kompass_h.UseVisualStyleBackColor = false;
            this.button_kompass_h.Click += new System.EventHandler(this.button_kompass_h_Click);
            // 
            // button_kompass
            // 
            this.button_kompass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_kompass.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_kompass.FlatAppearance.BorderSize = 0;
            this.button_kompass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_kompass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_kompass.Location = new System.Drawing.Point(0, 518);
            this.button_kompass.Name = "button_kompass";
            this.button_kompass.Size = new System.Drawing.Size(148, 46);
            this.button_kompass.TabIndex = 13;
            this.button_kompass.Text = "Compass";
            this.button_kompass.UseVisualStyleBackColor = false;
            this.button_kompass.Click += new System.EventHandler(this.button_kompass_Click);
            // 
            // panel_entitydisplay
            // 
            this.panel_entitydisplay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_entitydisplay.Controls.Add(this.button_entitydisplay_h);
            this.panel_entitydisplay.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_entitydisplay.Location = new System.Drawing.Point(0, 469);
            this.panel_entitydisplay.Name = "panel_entitydisplay";
            this.panel_entitydisplay.Size = new System.Drawing.Size(148, 49);
            this.panel_entitydisplay.TabIndex = 12;
            this.panel_entitydisplay.Visible = false;
            // 
            // button_entitydisplay_h
            // 
            this.button_entitydisplay_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_entitydisplay_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_entitydisplay_h.FlatAppearance.BorderSize = 0;
            this.button_entitydisplay_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_entitydisplay_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_entitydisplay_h.Location = new System.Drawing.Point(0, 0);
            this.button_entitydisplay_h.Name = "button_entitydisplay_h";
            this.button_entitydisplay_h.Size = new System.Drawing.Size(148, 38);
            this.button_entitydisplay_h.TabIndex = 2;
            this.button_entitydisplay_h.Text = "Hotkey:";
            this.button_entitydisplay_h.UseVisualStyleBackColor = false;
            this.button_entitydisplay_h.Click += new System.EventHandler(this.button_entitydisplay_h_Click);
            // 
            // button_entitydisplay
            // 
            this.button_entitydisplay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_entitydisplay.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_entitydisplay.FlatAppearance.BorderSize = 0;
            this.button_entitydisplay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_entitydisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_entitydisplay.Location = new System.Drawing.Point(0, 423);
            this.button_entitydisplay.Name = "button_entitydisplay";
            this.button_entitydisplay.Size = new System.Drawing.Size(148, 46);
            this.button_entitydisplay.TabIndex = 11;
            this.button_entitydisplay.Text = "EntityDisplay";
            this.button_entitydisplay.UseVisualStyleBackColor = false;
            this.button_entitydisplay.Click += new System.EventHandler(this.button_entitydisplay_Click);
            // 
            // panel_StopVisualTime
            // 
            this.panel_StopVisualTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_StopVisualTime.Controls.Add(this.button_stopvisualtime_h);
            this.panel_StopVisualTime.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_StopVisualTime.Location = new System.Drawing.Point(0, 374);
            this.panel_StopVisualTime.Name = "panel_StopVisualTime";
            this.panel_StopVisualTime.Size = new System.Drawing.Size(148, 49);
            this.panel_StopVisualTime.TabIndex = 10;
            this.panel_StopVisualTime.Visible = false;
            // 
            // button_stopvisualtime_h
            // 
            this.button_stopvisualtime_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_stopvisualtime_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_stopvisualtime_h.FlatAppearance.BorderSize = 0;
            this.button_stopvisualtime_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_stopvisualtime_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_stopvisualtime_h.Location = new System.Drawing.Point(0, 0);
            this.button_stopvisualtime_h.Name = "button_stopvisualtime_h";
            this.button_stopvisualtime_h.Size = new System.Drawing.Size(148, 38);
            this.button_stopvisualtime_h.TabIndex = 2;
            this.button_stopvisualtime_h.Text = "Hotkey:";
            this.button_stopvisualtime_h.UseVisualStyleBackColor = false;
            this.button_stopvisualtime_h.Click += new System.EventHandler(this.button_stopvisualtime_h_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button18.Dock = System.Windows.Forms.DockStyle.Top;
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button18.Location = new System.Drawing.Point(0, 328);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(148, 46);
            this.button18.TabIndex = 9;
            this.button18.Text = "StopVisualTime";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // panel_fulllight
            // 
            this.panel_fulllight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_fulllight.Controls.Add(this.button_fulllight_h);
            this.panel_fulllight.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_fulllight.Location = new System.Drawing.Point(0, 279);
            this.panel_fulllight.Name = "panel_fulllight";
            this.panel_fulllight.Size = new System.Drawing.Size(148, 49);
            this.panel_fulllight.TabIndex = 8;
            this.panel_fulllight.Visible = false;
            // 
            // button_fulllight_h
            // 
            this.button_fulllight_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_fulllight_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_fulllight_h.FlatAppearance.BorderSize = 0;
            this.button_fulllight_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_fulllight_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_fulllight_h.Location = new System.Drawing.Point(0, 0);
            this.button_fulllight_h.Name = "button_fulllight_h";
            this.button_fulllight_h.Size = new System.Drawing.Size(148, 38);
            this.button_fulllight_h.TabIndex = 2;
            this.button_fulllight_h.Text = "Hotkey:";
            this.button_fulllight_h.UseVisualStyleBackColor = false;
            this.button_fulllight_h.Click += new System.EventHandler(this.button_fulllight_h_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button16.Dock = System.Windows.Forms.DockStyle.Top;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button16.Location = new System.Drawing.Point(0, 233);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(148, 46);
            this.button16.TabIndex = 7;
            this.button16.Text = "Fulllight";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // panel_rainbowsky
            // 
            this.panel_rainbowsky.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_rainbowsky.Controls.Add(this.button_rainbowsky_h);
            this.panel_rainbowsky.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_rainbowsky.Location = new System.Drawing.Point(0, 184);
            this.panel_rainbowsky.Name = "panel_rainbowsky";
            this.panel_rainbowsky.Size = new System.Drawing.Size(148, 49);
            this.panel_rainbowsky.TabIndex = 6;
            this.panel_rainbowsky.Visible = false;
            // 
            // button_rainbowsky_h
            // 
            this.button_rainbowsky_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_rainbowsky_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_rainbowsky_h.FlatAppearance.BorderSize = 0;
            this.button_rainbowsky_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_rainbowsky_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_rainbowsky_h.Location = new System.Drawing.Point(0, 0);
            this.button_rainbowsky_h.Name = "button_rainbowsky_h";
            this.button_rainbowsky_h.Size = new System.Drawing.Size(148, 38);
            this.button_rainbowsky_h.TabIndex = 2;
            this.button_rainbowsky_h.Text = "Hotkey:";
            this.button_rainbowsky_h.UseVisualStyleBackColor = false;
            this.button_rainbowsky_h.Click += new System.EventHandler(this.button_rainbowsky_h_Click);
            // 
            // button_rainbowsky
            // 
            this.button_rainbowsky.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_rainbowsky.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_rainbowsky.FlatAppearance.BorderSize = 0;
            this.button_rainbowsky.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_rainbowsky.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_rainbowsky.Location = new System.Drawing.Point(0, 138);
            this.button_rainbowsky.Name = "button_rainbowsky";
            this.button_rainbowsky.Size = new System.Drawing.Size(148, 46);
            this.button_rainbowsky.TabIndex = 5;
            this.button_rainbowsky.Text = "Rainbowsky";
            this.button_rainbowsky.UseVisualStyleBackColor = false;
            this.button_rainbowsky.Click += new System.EventHandler(this.button_rainbowsky_Click);
            // 
            // panel_zoom
            // 
            this.panel_zoom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_zoom.Controls.Add(this.button_zoom_h);
            this.panel_zoom.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_zoom.Location = new System.Drawing.Point(0, 89);
            this.panel_zoom.Name = "panel_zoom";
            this.panel_zoom.Size = new System.Drawing.Size(148, 49);
            this.panel_zoom.TabIndex = 4;
            this.panel_zoom.Visible = false;
            // 
            // button_zoom_h
            // 
            this.button_zoom_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_zoom_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_zoom_h.FlatAppearance.BorderSize = 0;
            this.button_zoom_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_zoom_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_zoom_h.Location = new System.Drawing.Point(0, 0);
            this.button_zoom_h.Name = "button_zoom_h";
            this.button_zoom_h.Size = new System.Drawing.Size(148, 38);
            this.button_zoom_h.TabIndex = 2;
            this.button_zoom_h.Text = "Hotkey:";
            this.button_zoom_h.UseVisualStyleBackColor = false;
            this.button_zoom_h.Click += new System.EventHandler(this.button_zoom_h_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button13.Dock = System.Windows.Forms.DockStyle.Top;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button13.Location = new System.Drawing.Point(0, 43);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(148, 46);
            this.button13.TabIndex = 3;
            this.button13.Text = "Zoom";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(148, 43);
            this.panel3.TabIndex = 1;
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseMove);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.label2.Location = new System.Drawing.Point(42, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "Visuals";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.panel_speedsneak);
            this.panel1.Controls.Add(this.button21);
            this.panel1.Controls.Add(this.panel_phase);
            this.panel1.Controls.Add(this.button_phase);
            this.panel1.Controls.Add(this.panel_airwalk);
            this.panel1.Controls.Add(this.button_airwalk);
            this.panel1.Controls.Add(this.panel_infinityjump);
            this.panel1.Controls.Add(this.button_infinityjump);
            this.panel1.Controls.Add(this.panel_positionfreeze);
            this.panel1.Controls.Add(this.button_positionfreeze);
            this.panel1.Controls.Add(this.panel_glide);
            this.panel1.Controls.Add(this.button_glide);
            this.panel1.Controls.Add(this.panel_pglide);
            this.panel1.Controls.Add(this.button_pglide);
            this.panel1.Controls.Add(this.panel_highjump);
            this.panel1.Controls.Add(this.button_highjump);
            this.panel1.Controls.Add(this.panel_airjump);
            this.panel1.Controls.Add(this.button_airjump);
            this.panel1.Controls.Add(this.panel_speed);
            this.panel1.Controls.Add(this.button_speed);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Location = new System.Drawing.Point(538, 42);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(165, 486);
            this.panel1.TabIndex = 2;
            // 
            // panel_speedsneak
            // 
            this.panel_speedsneak.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_speedsneak.Controls.Add(this.button_speedsneak_h);
            this.panel_speedsneak.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_speedsneak.Location = new System.Drawing.Point(0, 1009);
            this.panel_speedsneak.Name = "panel_speedsneak";
            this.panel_speedsneak.Size = new System.Drawing.Size(148, 47);
            this.panel_speedsneak.TabIndex = 22;
            this.panel_speedsneak.Visible = false;
            // 
            // button_speedsneak_h
            // 
            this.button_speedsneak_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_speedsneak_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_speedsneak_h.FlatAppearance.BorderSize = 0;
            this.button_speedsneak_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_speedsneak_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_speedsneak_h.Location = new System.Drawing.Point(0, 0);
            this.button_speedsneak_h.Name = "button_speedsneak_h";
            this.button_speedsneak_h.Size = new System.Drawing.Size(148, 38);
            this.button_speedsneak_h.TabIndex = 2;
            this.button_speedsneak_h.Text = "Hotkey:";
            this.button_speedsneak_h.UseVisualStyleBackColor = false;
            this.button_speedsneak_h.Click += new System.EventHandler(this.button_speedsneak_h_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button21.Dock = System.Windows.Forms.DockStyle.Top;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button21.Location = new System.Drawing.Point(0, 961);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(148, 48);
            this.button21.TabIndex = 21;
            this.button21.Text = "SpeedSneak";
            this.button21.UseCompatibleTextRendering = true;
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // panel_phase
            // 
            this.panel_phase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_phase.Controls.Add(this.button_phase_h);
            this.panel_phase.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_phase.Location = new System.Drawing.Point(0, 907);
            this.panel_phase.Name = "panel_phase";
            this.panel_phase.Size = new System.Drawing.Size(148, 54);
            this.panel_phase.TabIndex = 20;
            this.panel_phase.Visible = false;
            // 
            // button_phase_h
            // 
            this.button_phase_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_phase_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_phase_h.FlatAppearance.BorderSize = 0;
            this.button_phase_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_phase_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_phase_h.Location = new System.Drawing.Point(0, 0);
            this.button_phase_h.Name = "button_phase_h";
            this.button_phase_h.Size = new System.Drawing.Size(148, 38);
            this.button_phase_h.TabIndex = 2;
            this.button_phase_h.Text = "Hotkey:";
            this.button_phase_h.UseVisualStyleBackColor = false;
            this.button_phase_h.Click += new System.EventHandler(this.button_phase_h_Click);
            // 
            // button_phase
            // 
            this.button_phase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_phase.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_phase.FlatAppearance.BorderSize = 0;
            this.button_phase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_phase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_phase.Location = new System.Drawing.Point(0, 861);
            this.button_phase.Name = "button_phase";
            this.button_phase.Size = new System.Drawing.Size(148, 46);
            this.button_phase.TabIndex = 19;
            this.button_phase.Text = "Phase";
            this.button_phase.UseCompatibleTextRendering = true;
            this.button_phase.UseVisualStyleBackColor = false;
            this.button_phase.Click += new System.EventHandler(this.button_phase_Click);
            // 
            // panel_airwalk
            // 
            this.panel_airwalk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_airwalk.Controls.Add(this.button_airwalk_h);
            this.panel_airwalk.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_airwalk.Location = new System.Drawing.Point(0, 804);
            this.panel_airwalk.Name = "panel_airwalk";
            this.panel_airwalk.Size = new System.Drawing.Size(148, 57);
            this.panel_airwalk.TabIndex = 18;
            this.panel_airwalk.Visible = false;
            // 
            // button_airwalk_h
            // 
            this.button_airwalk_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_airwalk_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_airwalk_h.FlatAppearance.BorderSize = 0;
            this.button_airwalk_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_airwalk_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_airwalk_h.Location = new System.Drawing.Point(0, 0);
            this.button_airwalk_h.Name = "button_airwalk_h";
            this.button_airwalk_h.Size = new System.Drawing.Size(148, 38);
            this.button_airwalk_h.TabIndex = 2;
            this.button_airwalk_h.Text = "Hotkey:";
            this.button_airwalk_h.UseVisualStyleBackColor = false;
            this.button_airwalk_h.Click += new System.EventHandler(this.button_airwalk_h_Click);
            // 
            // button_airwalk
            // 
            this.button_airwalk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_airwalk.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_airwalk.FlatAppearance.BorderSize = 0;
            this.button_airwalk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_airwalk.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_airwalk.Location = new System.Drawing.Point(0, 758);
            this.button_airwalk.Name = "button_airwalk";
            this.button_airwalk.Size = new System.Drawing.Size(148, 46);
            this.button_airwalk.TabIndex = 17;
            this.button_airwalk.Text = "AirWalk";
            this.button_airwalk.UseCompatibleTextRendering = true;
            this.button_airwalk.UseVisualStyleBackColor = false;
            this.button_airwalk.Click += new System.EventHandler(this.button_airwalk_Click);
            // 
            // panel_infinityjump
            // 
            this.panel_infinityjump.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_infinityjump.Controls.Add(this.button_infinijump_h);
            this.panel_infinityjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_infinityjump.Location = new System.Drawing.Point(0, 705);
            this.panel_infinityjump.Name = "panel_infinityjump";
            this.panel_infinityjump.Size = new System.Drawing.Size(148, 53);
            this.panel_infinityjump.TabIndex = 16;
            this.panel_infinityjump.Visible = false;
            // 
            // button_infinijump_h
            // 
            this.button_infinijump_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_infinijump_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_infinijump_h.FlatAppearance.BorderSize = 0;
            this.button_infinijump_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_infinijump_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_infinijump_h.Location = new System.Drawing.Point(0, 0);
            this.button_infinijump_h.Name = "button_infinijump_h";
            this.button_infinijump_h.Size = new System.Drawing.Size(148, 38);
            this.button_infinijump_h.TabIndex = 2;
            this.button_infinijump_h.Text = "Hotkey:";
            this.button_infinijump_h.UseVisualStyleBackColor = false;
            this.button_infinijump_h.Click += new System.EventHandler(this.button_infinijump_h_Click);
            // 
            // button_infinityjump
            // 
            this.button_infinityjump.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_infinityjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_infinityjump.FlatAppearance.BorderSize = 0;
            this.button_infinityjump.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_infinityjump.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_infinityjump.Location = new System.Drawing.Point(0, 659);
            this.button_infinityjump.Name = "button_infinityjump";
            this.button_infinityjump.Size = new System.Drawing.Size(148, 46);
            this.button_infinityjump.TabIndex = 15;
            this.button_infinityjump.Text = "Infinity Jump";
            this.button_infinityjump.UseCompatibleTextRendering = true;
            this.button_infinityjump.UseVisualStyleBackColor = false;
            this.button_infinityjump.Click += new System.EventHandler(this.button_infinityjump_Click);
            // 
            // panel_positionfreeze
            // 
            this.panel_positionfreeze.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_positionfreeze.Controls.Add(this.button_positionfreeze_h);
            this.panel_positionfreeze.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_positionfreeze.Location = new System.Drawing.Point(0, 599);
            this.panel_positionfreeze.Name = "panel_positionfreeze";
            this.panel_positionfreeze.Size = new System.Drawing.Size(148, 60);
            this.panel_positionfreeze.TabIndex = 14;
            this.panel_positionfreeze.Visible = false;
            // 
            // button_positionfreeze_h
            // 
            this.button_positionfreeze_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_positionfreeze_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_positionfreeze_h.FlatAppearance.BorderSize = 0;
            this.button_positionfreeze_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_positionfreeze_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_positionfreeze_h.Location = new System.Drawing.Point(0, 0);
            this.button_positionfreeze_h.Name = "button_positionfreeze_h";
            this.button_positionfreeze_h.Size = new System.Drawing.Size(148, 38);
            this.button_positionfreeze_h.TabIndex = 2;
            this.button_positionfreeze_h.Text = "Hotkey:";
            this.button_positionfreeze_h.UseVisualStyleBackColor = false;
            this.button_positionfreeze_h.Click += new System.EventHandler(this.button_positionfreeze_h_Click);
            // 
            // button_positionfreeze
            // 
            this.button_positionfreeze.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_positionfreeze.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_positionfreeze.FlatAppearance.BorderSize = 0;
            this.button_positionfreeze.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_positionfreeze.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_positionfreeze.Location = new System.Drawing.Point(0, 553);
            this.button_positionfreeze.Name = "button_positionfreeze";
            this.button_positionfreeze.Size = new System.Drawing.Size(148, 46);
            this.button_positionfreeze.TabIndex = 13;
            this.button_positionfreeze.Text = "PositionFreeze";
            this.button_positionfreeze.UseCompatibleTextRendering = true;
            this.button_positionfreeze.UseVisualStyleBackColor = false;
            this.button_positionfreeze.Click += new System.EventHandler(this.button_positionfreeze_Click);
            // 
            // panel_glide
            // 
            this.panel_glide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_glide.Controls.Add(this.button_glide_h);
            this.panel_glide.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_glide.Location = new System.Drawing.Point(0, 504);
            this.panel_glide.Name = "panel_glide";
            this.panel_glide.Size = new System.Drawing.Size(148, 49);
            this.panel_glide.TabIndex = 12;
            this.panel_glide.Visible = false;
            // 
            // button_glide_h
            // 
            this.button_glide_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_glide_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_glide_h.FlatAppearance.BorderSize = 0;
            this.button_glide_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_glide_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_glide_h.Location = new System.Drawing.Point(0, 0);
            this.button_glide_h.Name = "button_glide_h";
            this.button_glide_h.Size = new System.Drawing.Size(148, 38);
            this.button_glide_h.TabIndex = 2;
            this.button_glide_h.Text = "Hotkey:";
            this.button_glide_h.UseVisualStyleBackColor = false;
            this.button_glide_h.Click += new System.EventHandler(this.button_glide_h_Click);
            // 
            // button_glide
            // 
            this.button_glide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_glide.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_glide.FlatAppearance.BorderSize = 0;
            this.button_glide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_glide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_glide.Location = new System.Drawing.Point(0, 458);
            this.button_glide.Name = "button_glide";
            this.button_glide.Size = new System.Drawing.Size(148, 46);
            this.button_glide.TabIndex = 11;
            this.button_glide.Text = "Glide";
            this.button_glide.UseCompatibleTextRendering = true;
            this.button_glide.UseVisualStyleBackColor = false;
            this.button_glide.Click += new System.EventHandler(this.button_glide_Click);
            // 
            // panel_pglide
            // 
            this.panel_pglide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_pglide.Controls.Add(this.button_pglide_h);
            this.panel_pglide.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_pglide.Location = new System.Drawing.Point(0, 408);
            this.panel_pglide.Name = "panel_pglide";
            this.panel_pglide.Size = new System.Drawing.Size(148, 50);
            this.panel_pglide.TabIndex = 10;
            this.panel_pglide.Visible = false;
            // 
            // button_pglide_h
            // 
            this.button_pglide_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_pglide_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_pglide_h.FlatAppearance.BorderSize = 0;
            this.button_pglide_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pglide_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_pglide_h.Location = new System.Drawing.Point(0, 0);
            this.button_pglide_h.Name = "button_pglide_h";
            this.button_pglide_h.Size = new System.Drawing.Size(148, 38);
            this.button_pglide_h.TabIndex = 2;
            this.button_pglide_h.Text = "Hotkey:";
            this.button_pglide_h.UseVisualStyleBackColor = false;
            this.button_pglide_h.Click += new System.EventHandler(this.button_pglide_h_Click);
            // 
            // button_pglide
            // 
            this.button_pglide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_pglide.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_pglide.FlatAppearance.BorderSize = 0;
            this.button_pglide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pglide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_pglide.Location = new System.Drawing.Point(0, 362);
            this.button_pglide.Name = "button_pglide";
            this.button_pglide.Size = new System.Drawing.Size(148, 46);
            this.button_pglide.TabIndex = 9;
            this.button_pglide.Text = "P Glide";
            this.button_pglide.UseCompatibleTextRendering = true;
            this.button_pglide.UseVisualStyleBackColor = false;
            this.button_pglide.Click += new System.EventHandler(this.button_pglide_Click);
            // 
            // panel_highjump
            // 
            this.panel_highjump.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_highjump.Controls.Add(this.button_highjump_h);
            this.panel_highjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_highjump.Location = new System.Drawing.Point(0, 309);
            this.panel_highjump.Name = "panel_highjump";
            this.panel_highjump.Size = new System.Drawing.Size(148, 53);
            this.panel_highjump.TabIndex = 8;
            this.panel_highjump.Visible = false;
            // 
            // button_highjump_h
            // 
            this.button_highjump_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_highjump_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_highjump_h.FlatAppearance.BorderSize = 0;
            this.button_highjump_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_highjump_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_highjump_h.Location = new System.Drawing.Point(0, 0);
            this.button_highjump_h.Name = "button_highjump_h";
            this.button_highjump_h.Size = new System.Drawing.Size(148, 38);
            this.button_highjump_h.TabIndex = 2;
            this.button_highjump_h.Text = "Hotkey:";
            this.button_highjump_h.UseVisualStyleBackColor = false;
            this.button_highjump_h.Click += new System.EventHandler(this.button_highjump_h_Click);
            // 
            // button_highjump
            // 
            this.button_highjump.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_highjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_highjump.FlatAppearance.BorderSize = 0;
            this.button_highjump.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_highjump.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_highjump.Location = new System.Drawing.Point(0, 263);
            this.button_highjump.Name = "button_highjump";
            this.button_highjump.Size = new System.Drawing.Size(148, 46);
            this.button_highjump.TabIndex = 7;
            this.button_highjump.Text = "HighJump";
            this.button_highjump.UseVisualStyleBackColor = false;
            this.button_highjump.Click += new System.EventHandler(this.button_highjump_Click);
            // 
            // panel_airjump
            // 
            this.panel_airjump.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_airjump.Controls.Add(this.button_airjump_h);
            this.panel_airjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_airjump.Location = new System.Drawing.Point(0, 214);
            this.panel_airjump.Name = "panel_airjump";
            this.panel_airjump.Size = new System.Drawing.Size(148, 49);
            this.panel_airjump.TabIndex = 6;
            this.panel_airjump.Visible = false;
            // 
            // button_airjump_h
            // 
            this.button_airjump_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_airjump_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_airjump_h.FlatAppearance.BorderSize = 0;
            this.button_airjump_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_airjump_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_airjump_h.Location = new System.Drawing.Point(0, 0);
            this.button_airjump_h.Name = "button_airjump_h";
            this.button_airjump_h.Size = new System.Drawing.Size(148, 38);
            this.button_airjump_h.TabIndex = 2;
            this.button_airjump_h.Text = "Hotkey:";
            this.button_airjump_h.UseVisualStyleBackColor = false;
            this.button_airjump_h.Click += new System.EventHandler(this.button_airjump_h_Click);
            // 
            // button_airjump
            // 
            this.button_airjump.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_airjump.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_airjump.FlatAppearance.BorderSize = 0;
            this.button_airjump.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_airjump.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_airjump.Location = new System.Drawing.Point(0, 168);
            this.button_airjump.Name = "button_airjump";
            this.button_airjump.Size = new System.Drawing.Size(148, 46);
            this.button_airjump.TabIndex = 5;
            this.button_airjump.Text = "AirJump";
            this.button_airjump.UseVisualStyleBackColor = false;
            this.button_airjump.Click += new System.EventHandler(this.button_airjump_Click);
            // 
            // panel_speed
            // 
            this.panel_speed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_speed.Controls.Add(this.trackBar3);
            this.panel_speed.Controls.Add(this.button_speed_h);
            this.panel_speed.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_speed.Location = new System.Drawing.Point(0, 89);
            this.panel_speed.Name = "panel_speed";
            this.panel_speed.Size = new System.Drawing.Size(148, 79);
            this.panel_speed.TabIndex = 4;
            this.panel_speed.Visible = false;
            // 
            // trackBar3
            // 
            this.trackBar3.Location = new System.Drawing.Point(26, 44);
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Size = new System.Drawing.Size(104, 45);
            this.trackBar3.TabIndex = 3;
            // 
            // button_speed_h
            // 
            this.button_speed_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_speed_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_speed_h.FlatAppearance.BorderSize = 0;
            this.button_speed_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_speed_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_speed_h.Location = new System.Drawing.Point(0, 0);
            this.button_speed_h.Name = "button_speed_h";
            this.button_speed_h.Size = new System.Drawing.Size(148, 38);
            this.button_speed_h.TabIndex = 2;
            this.button_speed_h.Text = "Hotkey:";
            this.button_speed_h.UseVisualStyleBackColor = false;
            this.button_speed_h.Click += new System.EventHandler(this.button_speed_h_Click);
            // 
            // button_speed
            // 
            this.button_speed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_speed.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_speed.FlatAppearance.BorderSize = 0;
            this.button_speed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_speed.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_speed.Location = new System.Drawing.Point(0, 43);
            this.button_speed.Name = "button_speed";
            this.button_speed.Size = new System.Drawing.Size(148, 46);
            this.button_speed.TabIndex = 3;
            this.button_speed.Text = "Speed";
            this.button_speed.UseVisualStyleBackColor = false;
            this.button_speed.Click += new System.EventHandler(this.button_speed_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label3);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(148, 43);
            this.panel8.TabIndex = 1;
            this.panel8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel8_MouseDown_1);
            this.panel8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel8_MouseMove_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.label3.Location = new System.Drawing.Point(52, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "Mov";
            // 
            // panel_exploits
            // 
            this.panel_exploits.AutoScroll = true;
            this.panel_exploits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.panel_exploits.Controls.Add(this.panel_targetstraffe);
            this.panel_exploits.Controls.Add(this.button_tragtetstraffe);
            this.panel_exploits.Controls.Add(this.panel_fakegamemode);
            this.panel_exploits.Controls.Add(this.button_fakegamemode);
            this.panel_exploits.Controls.Add(this.panel_scaffold);
            this.panel_exploits.Controls.Add(this.button_scaffold);
            this.panel_exploits.Controls.Add(this.panel_norender);
            this.panel_exploits.Controls.Add(this.button_norender);
            this.panel_exploits.Controls.Add(this.panel_antivoid);
            this.panel_exploits.Controls.Add(this.button_antivoid);
            this.panel_exploits.Controls.Add(this.panel_FlyDamageBypass);
            this.panel_exploits.Controls.Add(this.button_FlyDamageBypass);
            this.panel_exploits.Controls.Add(this.panel_nofall);
            this.panel_exploits.Controls.Add(this.button23);
            this.panel_exploits.Controls.Add(this.panel5);
            this.panel_exploits.Location = new System.Drawing.Point(746, 42);
            this.panel_exploits.Name = "panel_exploits";
            this.panel_exploits.Size = new System.Drawing.Size(162, 273);
            this.panel_exploits.TabIndex = 3;
            // 
            // panel_targetstraffe
            // 
            this.panel_targetstraffe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_targetstraffe.Controls.Add(this.button_targetstraffe_h);
            this.panel_targetstraffe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_targetstraffe.Location = new System.Drawing.Point(0, 693);
            this.panel_targetstraffe.Name = "panel_targetstraffe";
            this.panel_targetstraffe.Size = new System.Drawing.Size(145, 51);
            this.panel_targetstraffe.TabIndex = 18;
            this.panel_targetstraffe.Visible = false;
            // 
            // button_targetstraffe_h
            // 
            this.button_targetstraffe_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_targetstraffe_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_targetstraffe_h.FlatAppearance.BorderSize = 0;
            this.button_targetstraffe_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_targetstraffe_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_targetstraffe_h.Location = new System.Drawing.Point(0, 0);
            this.button_targetstraffe_h.Name = "button_targetstraffe_h";
            this.button_targetstraffe_h.Size = new System.Drawing.Size(145, 38);
            this.button_targetstraffe_h.TabIndex = 2;
            this.button_targetstraffe_h.Text = "Hotkey:";
            this.button_targetstraffe_h.UseVisualStyleBackColor = false;
            this.button_targetstraffe_h.Click += new System.EventHandler(this.button_targetstraffe_h_Click);
            // 
            // button_tragtetstraffe
            // 
            this.button_tragtetstraffe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_tragtetstraffe.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_tragtetstraffe.FlatAppearance.BorderSize = 0;
            this.button_tragtetstraffe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_tragtetstraffe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_tragtetstraffe.Location = new System.Drawing.Point(0, 647);
            this.button_tragtetstraffe.Name = "button_tragtetstraffe";
            this.button_tragtetstraffe.Size = new System.Drawing.Size(145, 46);
            this.button_tragtetstraffe.TabIndex = 17;
            this.button_tragtetstraffe.Text = "TargetStraffe";
            this.button_tragtetstraffe.UseVisualStyleBackColor = false;
            this.button_tragtetstraffe.Click += new System.EventHandler(this.button_tragtetstraffe_Click);
            // 
            // panel_fakegamemode
            // 
            this.panel_fakegamemode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_fakegamemode.Controls.Add(this.button_fakegamemode_h);
            this.panel_fakegamemode.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_fakegamemode.Location = new System.Drawing.Point(0, 596);
            this.panel_fakegamemode.Name = "panel_fakegamemode";
            this.panel_fakegamemode.Size = new System.Drawing.Size(145, 51);
            this.panel_fakegamemode.TabIndex = 16;
            this.panel_fakegamemode.Visible = false;
            // 
            // button_fakegamemode_h
            // 
            this.button_fakegamemode_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_fakegamemode_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_fakegamemode_h.FlatAppearance.BorderSize = 0;
            this.button_fakegamemode_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_fakegamemode_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_fakegamemode_h.Location = new System.Drawing.Point(0, 0);
            this.button_fakegamemode_h.Name = "button_fakegamemode_h";
            this.button_fakegamemode_h.Size = new System.Drawing.Size(145, 38);
            this.button_fakegamemode_h.TabIndex = 2;
            this.button_fakegamemode_h.Text = "Hotkey:";
            this.button_fakegamemode_h.UseVisualStyleBackColor = false;
            this.button_fakegamemode_h.Click += new System.EventHandler(this.button_fakegamemode_h_Click);
            // 
            // button_fakegamemode
            // 
            this.button_fakegamemode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_fakegamemode.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_fakegamemode.FlatAppearance.BorderSize = 0;
            this.button_fakegamemode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_fakegamemode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_fakegamemode.Location = new System.Drawing.Point(0, 550);
            this.button_fakegamemode.Name = "button_fakegamemode";
            this.button_fakegamemode.Size = new System.Drawing.Size(145, 46);
            this.button_fakegamemode.TabIndex = 15;
            this.button_fakegamemode.Text = "FakeGamemode";
            this.button_fakegamemode.UseVisualStyleBackColor = false;
            // 
            // panel_scaffold
            // 
            this.panel_scaffold.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_scaffold.Controls.Add(this.button_scaffold_h);
            this.panel_scaffold.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_scaffold.Location = new System.Drawing.Point(0, 477);
            this.panel_scaffold.Name = "panel_scaffold";
            this.panel_scaffold.Size = new System.Drawing.Size(145, 73);
            this.panel_scaffold.TabIndex = 14;
            this.panel_scaffold.Visible = false;
            // 
            // button_scaffold_h
            // 
            this.button_scaffold_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_scaffold_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_scaffold_h.FlatAppearance.BorderSize = 0;
            this.button_scaffold_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_scaffold_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_scaffold_h.Location = new System.Drawing.Point(0, 0);
            this.button_scaffold_h.Name = "button_scaffold_h";
            this.button_scaffold_h.Size = new System.Drawing.Size(145, 38);
            this.button_scaffold_h.TabIndex = 2;
            this.button_scaffold_h.Text = "Hotkey:";
            this.button_scaffold_h.UseVisualStyleBackColor = false;
            this.button_scaffold_h.Click += new System.EventHandler(this.button_scaffold_h_Click);
            // 
            // button_scaffold
            // 
            this.button_scaffold.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_scaffold.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_scaffold.FlatAppearance.BorderSize = 0;
            this.button_scaffold.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_scaffold.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_scaffold.Location = new System.Drawing.Point(0, 431);
            this.button_scaffold.Name = "button_scaffold";
            this.button_scaffold.Size = new System.Drawing.Size(145, 46);
            this.button_scaffold.TabIndex = 13;
            this.button_scaffold.Text = "Scaffold";
            this.button_scaffold.UseVisualStyleBackColor = false;
            this.button_scaffold.Click += new System.EventHandler(this.button_scaffold_Click_1);
            // 
            // panel_norender
            // 
            this.panel_norender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_norender.Controls.Add(this.button_norender_h);
            this.panel_norender.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_norender.Location = new System.Drawing.Point(0, 380);
            this.panel_norender.Name = "panel_norender";
            this.panel_norender.Size = new System.Drawing.Size(145, 51);
            this.panel_norender.TabIndex = 12;
            this.panel_norender.Visible = false;
            // 
            // button_norender_h
            // 
            this.button_norender_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_norender_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_norender_h.FlatAppearance.BorderSize = 0;
            this.button_norender_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_norender_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_norender_h.Location = new System.Drawing.Point(0, 0);
            this.button_norender_h.Name = "button_norender_h";
            this.button_norender_h.Size = new System.Drawing.Size(145, 38);
            this.button_norender_h.TabIndex = 2;
            this.button_norender_h.Text = "Hotkey:";
            this.button_norender_h.UseVisualStyleBackColor = false;
            this.button_norender_h.Click += new System.EventHandler(this.button_norender_h_Click);
            // 
            // button_norender
            // 
            this.button_norender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_norender.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_norender.FlatAppearance.BorderSize = 0;
            this.button_norender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_norender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_norender.Location = new System.Drawing.Point(0, 334);
            this.button_norender.Name = "button_norender";
            this.button_norender.Size = new System.Drawing.Size(145, 46);
            this.button_norender.TabIndex = 11;
            this.button_norender.Text = "NoRender";
            this.button_norender.UseVisualStyleBackColor = false;
            this.button_norender.Click += new System.EventHandler(this.button_norender_Click);
            // 
            // panel_antivoid
            // 
            this.panel_antivoid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_antivoid.Controls.Add(this.button_antivoid_h);
            this.panel_antivoid.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_antivoid.Location = new System.Drawing.Point(0, 283);
            this.panel_antivoid.Name = "panel_antivoid";
            this.panel_antivoid.Size = new System.Drawing.Size(145, 51);
            this.panel_antivoid.TabIndex = 10;
            this.panel_antivoid.Visible = false;
            // 
            // button_antivoid_h
            // 
            this.button_antivoid_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_antivoid_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_antivoid_h.FlatAppearance.BorderSize = 0;
            this.button_antivoid_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_antivoid_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_antivoid_h.Location = new System.Drawing.Point(0, 0);
            this.button_antivoid_h.Name = "button_antivoid_h";
            this.button_antivoid_h.Size = new System.Drawing.Size(145, 38);
            this.button_antivoid_h.TabIndex = 2;
            this.button_antivoid_h.Text = "Hotkey:";
            this.button_antivoid_h.UseVisualStyleBackColor = false;
            this.button_antivoid_h.Click += new System.EventHandler(this.button_antivoid_h_Click);
            // 
            // button_antivoid
            // 
            this.button_antivoid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_antivoid.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_antivoid.FlatAppearance.BorderSize = 0;
            this.button_antivoid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_antivoid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_antivoid.Location = new System.Drawing.Point(0, 237);
            this.button_antivoid.Name = "button_antivoid";
            this.button_antivoid.Size = new System.Drawing.Size(145, 46);
            this.button_antivoid.TabIndex = 9;
            this.button_antivoid.Text = "AntiVoid";
            this.button_antivoid.UseVisualStyleBackColor = false;
            this.button_antivoid.Click += new System.EventHandler(this.button_antivoid_Click);
            // 
            // panel_FlyDamageBypass
            // 
            this.panel_FlyDamageBypass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_FlyDamageBypass.Controls.Add(this.button_flydamagebypass_h);
            this.panel_FlyDamageBypass.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_FlyDamageBypass.Location = new System.Drawing.Point(0, 186);
            this.panel_FlyDamageBypass.Name = "panel_FlyDamageBypass";
            this.panel_FlyDamageBypass.Size = new System.Drawing.Size(145, 51);
            this.panel_FlyDamageBypass.TabIndex = 8;
            this.panel_FlyDamageBypass.Visible = false;
            // 
            // button_flydamagebypass_h
            // 
            this.button_flydamagebypass_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_flydamagebypass_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_flydamagebypass_h.FlatAppearance.BorderSize = 0;
            this.button_flydamagebypass_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_flydamagebypass_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_flydamagebypass_h.Location = new System.Drawing.Point(0, 0);
            this.button_flydamagebypass_h.Name = "button_flydamagebypass_h";
            this.button_flydamagebypass_h.Size = new System.Drawing.Size(145, 38);
            this.button_flydamagebypass_h.TabIndex = 2;
            this.button_flydamagebypass_h.Text = "Hotkey:";
            this.button_flydamagebypass_h.UseVisualStyleBackColor = false;
            this.button_flydamagebypass_h.Click += new System.EventHandler(this.button_flydamagebypass_h_Click);
            // 
            // button_FlyDamageBypass
            // 
            this.button_FlyDamageBypass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_FlyDamageBypass.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_FlyDamageBypass.FlatAppearance.BorderSize = 0;
            this.button_FlyDamageBypass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_FlyDamageBypass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_FlyDamageBypass.Location = new System.Drawing.Point(0, 140);
            this.button_FlyDamageBypass.Name = "button_FlyDamageBypass";
            this.button_FlyDamageBypass.Size = new System.Drawing.Size(145, 46);
            this.button_FlyDamageBypass.TabIndex = 7;
            this.button_FlyDamageBypass.Text = "FlyDamageBypass";
            this.button_FlyDamageBypass.UseVisualStyleBackColor = false;
            this.button_FlyDamageBypass.Click += new System.EventHandler(this.button_FlyDamageBypass_Click);
            // 
            // panel_nofall
            // 
            this.panel_nofall.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_nofall.Controls.Add(this.button_nofall_h);
            this.panel_nofall.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_nofall.Location = new System.Drawing.Point(0, 89);
            this.panel_nofall.Name = "panel_nofall";
            this.panel_nofall.Size = new System.Drawing.Size(145, 51);
            this.panel_nofall.TabIndex = 6;
            this.panel_nofall.Visible = false;
            // 
            // button_nofall_h
            // 
            this.button_nofall_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_nofall_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_nofall_h.FlatAppearance.BorderSize = 0;
            this.button_nofall_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_nofall_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_nofall_h.Location = new System.Drawing.Point(0, 0);
            this.button_nofall_h.Name = "button_nofall_h";
            this.button_nofall_h.Size = new System.Drawing.Size(145, 38);
            this.button_nofall_h.TabIndex = 2;
            this.button_nofall_h.Text = "Hotkey:";
            this.button_nofall_h.UseVisualStyleBackColor = false;
            this.button_nofall_h.Click += new System.EventHandler(this.button_nofall_h_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button23.Dock = System.Windows.Forms.DockStyle.Top;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button23.Location = new System.Drawing.Point(0, 43);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(145, 46);
            this.button23.TabIndex = 5;
            this.button23.Text = "NoFall";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(145, 43);
            this.panel5.TabIndex = 2;
            this.panel5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel5_MouseDown);
            this.panel5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel5_MouseMove);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.label4.Location = new System.Drawing.Point(47, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "Exploits";
            // 
            // panel_settings
            // 
            this.panel_settings.AutoScroll = true;
            this.panel_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.panel_settings.Controls.Add(this.panel_watermark);
            this.panel_settings.Controls.Add(this.button_watermark);
            this.panel_settings.Controls.Add(this.panel_arraylist);
            this.panel_settings.Controls.Add(this.button_arraylist);
            this.panel_settings.Controls.Add(this.panel_tabgui);
            this.panel_settings.Controls.Add(this.button_tabgui);
            this.panel_settings.Controls.Add(this.panel_clickgui);
            this.panel_settings.Controls.Add(this.button_clickgui);
            this.panel_settings.Controls.Add(this.panel_keystrokes);
            this.panel_settings.Controls.Add(this.button30);
            this.panel_settings.Controls.Add(this.panel6);
            this.panel_settings.Location = new System.Drawing.Point(933, 42);
            this.panel_settings.Name = "panel_settings";
            this.panel_settings.Size = new System.Drawing.Size(162, 233);
            this.panel_settings.TabIndex = 4;
            // 
            // panel_watermark
            // 
            this.panel_watermark.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_watermark.Controls.Add(this.button_watermark_h);
            this.panel_watermark.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_watermark.Location = new System.Drawing.Point(0, 619);
            this.panel_watermark.Name = "panel_watermark";
            this.panel_watermark.Size = new System.Drawing.Size(145, 90);
            this.panel_watermark.TabIndex = 16;
            this.panel_watermark.Visible = false;
            // 
            // button_watermark_h
            // 
            this.button_watermark_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_watermark_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_watermark_h.FlatAppearance.BorderSize = 0;
            this.button_watermark_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_watermark_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_watermark_h.Location = new System.Drawing.Point(0, 0);
            this.button_watermark_h.Name = "button_watermark_h";
            this.button_watermark_h.Size = new System.Drawing.Size(145, 38);
            this.button_watermark_h.TabIndex = 2;
            this.button_watermark_h.Text = "Hotkey:";
            this.button_watermark_h.UseVisualStyleBackColor = false;
            this.button_watermark_h.Click += new System.EventHandler(this.button_watermark_h_Click);
            // 
            // button_watermark
            // 
            this.button_watermark.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_watermark.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_watermark.FlatAppearance.BorderSize = 0;
            this.button_watermark.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_watermark.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_watermark.Location = new System.Drawing.Point(0, 576);
            this.button_watermark.Name = "button_watermark";
            this.button_watermark.Size = new System.Drawing.Size(145, 43);
            this.button_watermark.TabIndex = 15;
            this.button_watermark.Text = "Watermark";
            this.button_watermark.UseVisualStyleBackColor = false;
            this.button_watermark.Click += new System.EventHandler(this.button_watermark_Click);
            // 
            // panel_arraylist
            // 
            this.panel_arraylist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_arraylist.Controls.Add(this.button_arraylist_h);
            this.panel_arraylist.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_arraylist.Location = new System.Drawing.Point(0, 486);
            this.panel_arraylist.Name = "panel_arraylist";
            this.panel_arraylist.Size = new System.Drawing.Size(145, 90);
            this.panel_arraylist.TabIndex = 14;
            this.panel_arraylist.Visible = false;
            // 
            // button_arraylist_h
            // 
            this.button_arraylist_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_arraylist_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_arraylist_h.FlatAppearance.BorderSize = 0;
            this.button_arraylist_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_arraylist_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_arraylist_h.Location = new System.Drawing.Point(0, 0);
            this.button_arraylist_h.Name = "button_arraylist_h";
            this.button_arraylist_h.Size = new System.Drawing.Size(145, 38);
            this.button_arraylist_h.TabIndex = 2;
            this.button_arraylist_h.Text = "Hotkey:";
            this.button_arraylist_h.UseVisualStyleBackColor = false;
            this.button_arraylist_h.Click += new System.EventHandler(this.button_arraylist_h_Click);
            // 
            // button_arraylist
            // 
            this.button_arraylist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_arraylist.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_arraylist.FlatAppearance.BorderSize = 0;
            this.button_arraylist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_arraylist.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_arraylist.Location = new System.Drawing.Point(0, 443);
            this.button_arraylist.Name = "button_arraylist";
            this.button_arraylist.Size = new System.Drawing.Size(145, 43);
            this.button_arraylist.TabIndex = 13;
            this.button_arraylist.Text = "Arraylist";
            this.button_arraylist.UseVisualStyleBackColor = false;
            this.button_arraylist.Click += new System.EventHandler(this.button_arraylist_Click);
            // 
            // panel_tabgui
            // 
            this.panel_tabgui.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_tabgui.Controls.Add(this.button_tabgui_h);
            this.panel_tabgui.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_tabgui.Location = new System.Drawing.Point(0, 353);
            this.panel_tabgui.Name = "panel_tabgui";
            this.panel_tabgui.Size = new System.Drawing.Size(145, 90);
            this.panel_tabgui.TabIndex = 12;
            this.panel_tabgui.Visible = false;
            // 
            // button_tabgui_h
            // 
            this.button_tabgui_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_tabgui_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_tabgui_h.FlatAppearance.BorderSize = 0;
            this.button_tabgui_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_tabgui_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_tabgui_h.Location = new System.Drawing.Point(0, 0);
            this.button_tabgui_h.Name = "button_tabgui_h";
            this.button_tabgui_h.Size = new System.Drawing.Size(145, 38);
            this.button_tabgui_h.TabIndex = 2;
            this.button_tabgui_h.Text = "Hotkey:";
            this.button_tabgui_h.UseVisualStyleBackColor = false;
            this.button_tabgui_h.Click += new System.EventHandler(this.button_tabgui_h_Click);
            // 
            // button_tabgui
            // 
            this.button_tabgui.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_tabgui.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_tabgui.FlatAppearance.BorderSize = 0;
            this.button_tabgui.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_tabgui.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_tabgui.Location = new System.Drawing.Point(0, 310);
            this.button_tabgui.Name = "button_tabgui";
            this.button_tabgui.Size = new System.Drawing.Size(145, 43);
            this.button_tabgui.TabIndex = 11;
            this.button_tabgui.Text = "TabGui";
            this.button_tabgui.UseVisualStyleBackColor = false;
            this.button_tabgui.Click += new System.EventHandler(this.button_tabgui_Click);
            // 
            // panel_clickgui
            // 
            this.panel_clickgui.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_clickgui.Controls.Add(this.button_clickgui_hotkey);
            this.panel_clickgui.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_clickgui.Location = new System.Drawing.Point(0, 222);
            this.panel_clickgui.Name = "panel_clickgui";
            this.panel_clickgui.Size = new System.Drawing.Size(145, 88);
            this.panel_clickgui.TabIndex = 10;
            this.panel_clickgui.Visible = false;
            // 
            // button_clickgui_hotkey
            // 
            this.button_clickgui_hotkey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_clickgui_hotkey.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_clickgui_hotkey.FlatAppearance.BorderSize = 0;
            this.button_clickgui_hotkey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_clickgui_hotkey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_clickgui_hotkey.Location = new System.Drawing.Point(0, 0);
            this.button_clickgui_hotkey.Name = "button_clickgui_hotkey";
            this.button_clickgui_hotkey.Size = new System.Drawing.Size(145, 38);
            this.button_clickgui_hotkey.TabIndex = 2;
            this.button_clickgui_hotkey.Text = "Hotkey: Insert";
            this.button_clickgui_hotkey.UseVisualStyleBackColor = false;
            this.button_clickgui_hotkey.Click += new System.EventHandler(this.button_clickgui_hotkey_Click);
            // 
            // button_clickgui
            // 
            this.button_clickgui.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button_clickgui.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_clickgui.FlatAppearance.BorderSize = 0;
            this.button_clickgui.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_clickgui.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_clickgui.Location = new System.Drawing.Point(0, 178);
            this.button_clickgui.Name = "button_clickgui";
            this.button_clickgui.Size = new System.Drawing.Size(145, 44);
            this.button_clickgui.TabIndex = 9;
            this.button_clickgui.Text = "ClickGui";
            this.button_clickgui.UseVisualStyleBackColor = false;
            this.button_clickgui.Click += new System.EventHandler(this.button_clickgui_Click);
            // 
            // panel_keystrokes
            // 
            this.panel_keystrokes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(87)))));
            this.panel_keystrokes.Controls.Add(this.button_keystrokes_h);
            this.panel_keystrokes.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_keystrokes.Location = new System.Drawing.Point(0, 89);
            this.panel_keystrokes.Name = "panel_keystrokes";
            this.panel_keystrokes.Size = new System.Drawing.Size(145, 89);
            this.panel_keystrokes.TabIndex = 8;
            this.panel_keystrokes.Visible = false;
            // 
            // button_keystrokes_h
            // 
            this.button_keystrokes_h.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(58)))), ((int)(((byte)(64)))));
            this.button_keystrokes_h.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_keystrokes_h.FlatAppearance.BorderSize = 0;
            this.button_keystrokes_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_keystrokes_h.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button_keystrokes_h.Location = new System.Drawing.Point(0, 0);
            this.button_keystrokes_h.Name = "button_keystrokes_h";
            this.button_keystrokes_h.Size = new System.Drawing.Size(145, 38);
            this.button_keystrokes_h.TabIndex = 2;
            this.button_keystrokes_h.Text = "Hotkey:";
            this.button_keystrokes_h.UseVisualStyleBackColor = false;
            this.button_keystrokes_h.Click += new System.EventHandler(this.button_keystrokes_h_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(37)))), ((int)(((byte)(41)))));
            this.button30.Dock = System.Windows.Forms.DockStyle.Top;
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.button30.Location = new System.Drawing.Point(0, 43);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(145, 46);
            this.button30.TabIndex = 7;
            this.button30.Text = "KeyStrokes";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label5);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(145, 43);
            this.panel6.TabIndex = 3;
            this.panel6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel6_MouseDown);
            this.panel6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel6_MouseMove);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(226)))), ((int)(((byte)(230)))));
            this.label5.Location = new System.Drawing.Point(47, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "Settings";
            // 
            // timer_aimbot
            // 
            this.timer_aimbot.Interval = 10;
            this.timer_aimbot.Tick += new System.EventHandler(this.timer_aimbot_Tick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(12, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "by Jan!";
            // 
            // ClickGui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1292, 1100);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel_settings);
            this.Controls.Add(this.panel_exploits);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_visuals);
            this.Controls.Add(this.panel_combo);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ClickGui";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_combo.ResumeLayout(false);
            this.panel_aimbot.ResumeLayout(false);
            this.panel_triggerbot.ResumeLayout(false);
            this.panel_AutoClicker.ResumeLayout(false);
            this.panel_AutoClicker.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.panel_Infinityblockreach.ResumeLayout(false);
            this.panel_Infinityblockreach.PerformLayout();
            this.panel_noknockback.ResumeLayout(false);
            this.panel_instantbreak.ResumeLayout(false);
            this.panel_hitbox.ResumeLayout(false);
            this.panel_hitbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_hitbox_withe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_hitbox_high)).EndInit();
            this.panel_reach.ResumeLayout(false);
            this.panel_reach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_reach)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel_visuals.ResumeLayout(false);
            this.panel_kompass.ResumeLayout(false);
            this.panel_entitydisplay.ResumeLayout(false);
            this.panel_StopVisualTime.ResumeLayout(false);
            this.panel_fulllight.ResumeLayout(false);
            this.panel_rainbowsky.ResumeLayout(false);
            this.panel_zoom.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel_speedsneak.ResumeLayout(false);
            this.panel_phase.ResumeLayout(false);
            this.panel_airwalk.ResumeLayout(false);
            this.panel_infinityjump.ResumeLayout(false);
            this.panel_positionfreeze.ResumeLayout(false);
            this.panel_glide.ResumeLayout(false);
            this.panel_pglide.ResumeLayout(false);
            this.panel_highjump.ResumeLayout(false);
            this.panel_airjump.ResumeLayout(false);
            this.panel_speed.ResumeLayout(false);
            this.panel_speed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel_exploits.ResumeLayout(false);
            this.panel_targetstraffe.ResumeLayout(false);
            this.panel_fakegamemode.ResumeLayout(false);
            this.panel_scaffold.ResumeLayout(false);
            this.panel_norender.ResumeLayout(false);
            this.panel_antivoid.ResumeLayout(false);
            this.panel_FlyDamageBypass.ResumeLayout(false);
            this.panel_nofall.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel_settings.ResumeLayout(false);
            this.panel_watermark.ResumeLayout(false);
            this.panel_arraylist.ResumeLayout(false);
            this.panel_tabgui.ResumeLayout(false);
            this.panel_clickgui.ResumeLayout(false);
            this.panel_keystrokes.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_combo;
        private System.Windows.Forms.Button button_reach;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel_reach;
        private System.Windows.Forms.Button button_reach_hotkey;
        private System.Windows.Forms.TrackBar trackBar_reach;
        private System.Windows.Forms.Panel panel_hitbox;
        public System.Windows.Forms.TrackBar trackBar_hitbox_high;
        private System.Windows.Forms.Button button_hitbox_hotkey;
        private System.Windows.Forms.Button button_hitbox;
        private System.Windows.Forms.Panel panel_instantbreak;
        private System.Windows.Forms.Button button_instantbreak_hotkey;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel_noknockback;
        private System.Windows.Forms.Button button_noknockback_hotkey;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel_Infinityblockreach;
        private System.Windows.Forms.TextBox textBox_Infinityblockreach;
        private System.Windows.Forms.Button button_Infinityblockreach_hotkey;
        private System.Windows.Forms.Button button_Infinityblockreach;
        private System.Windows.Forms.Panel panel_AutoClicker;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Button button_AutoClicker_hotkey;
        private System.Windows.Forms.Button button_AutoClicker;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel_triggerbot;
        private System.Windows.Forms.Button button_triggerbot_hotkey;
        private System.Windows.Forms.Button button_triggerbot;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_visuals;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_pglide;
        private System.Windows.Forms.Button button_pglide_h;
        private System.Windows.Forms.Button button_pglide;
        private System.Windows.Forms.Panel panel_highjump;
        private System.Windows.Forms.Button button_highjump_h;
        private System.Windows.Forms.Button button_highjump;
        private System.Windows.Forms.Panel panel_airjump;
        private System.Windows.Forms.Button button_airjump_h;
        private System.Windows.Forms.Button button_airjump;
        private System.Windows.Forms.Panel panel_speed;
        private System.Windows.Forms.Button button_speed_h;
        private System.Windows.Forms.Button button_speed;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel_rainbowsky;
        private System.Windows.Forms.Button button_rainbowsky_h;
        private System.Windows.Forms.Button button_rainbowsky;
        private System.Windows.Forms.Panel panel_zoom;
        private System.Windows.Forms.Button button_zoom_h;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel panel_fulllight;
        private System.Windows.Forms.Button button_fulllight_h;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Panel panel_StopVisualTime;
        private System.Windows.Forms.Button button_stopvisualtime_h;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel_glide;
        private System.Windows.Forms.Button button_glide_h;
        private System.Windows.Forms.Button button_glide;
        private System.Windows.Forms.Panel panel_airwalk;
        private System.Windows.Forms.Button button_airwalk_h;
        private System.Windows.Forms.Button button_airwalk;
        private System.Windows.Forms.Panel panel_infinityjump;
        private System.Windows.Forms.Button button_infinijump_h;
        private System.Windows.Forms.Button button_infinityjump;
        private System.Windows.Forms.Panel panel_positionfreeze;
        private System.Windows.Forms.Button button_positionfreeze_h;
        private System.Windows.Forms.Button button_positionfreeze;
        private System.Windows.Forms.Panel panel_phase;
        private System.Windows.Forms.Button button_phase_h;
        private System.Windows.Forms.Button button_phase;
        private System.Windows.Forms.Panel panel_speedsneak;
        private System.Windows.Forms.Button button_speedsneak_h;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Panel panel_exploits;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel_FlyDamageBypass;
        private System.Windows.Forms.Button button_flydamagebypass_h;
        private System.Windows.Forms.Button button_FlyDamageBypass;
        private System.Windows.Forms.Panel panel_nofall;
        private System.Windows.Forms.Button button_nofall_h;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Panel panel_antivoid;
        private System.Windows.Forms.Button button_antivoid_h;
        private System.Windows.Forms.Button button_antivoid;
        private System.Windows.Forms.Panel panel_norender;
        private System.Windows.Forms.Button button_norender_h;
        private System.Windows.Forms.Button button_norender;
        private System.Windows.Forms.Panel panel_scaffold;
        private System.Windows.Forms.Button button_scaffold_h;
        private System.Windows.Forms.Button button_scaffold;
        private System.Windows.Forms.Panel panel_fakegamemode;
        private System.Windows.Forms.Button button_fakegamemode_h;
        private System.Windows.Forms.Button button_fakegamemode;
        private System.Windows.Forms.Panel panel_settings;
        private System.Windows.Forms.Panel panel_keystrokes;
        private System.Windows.Forms.Button button_keystrokes_h;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel_clickgui;
        private System.Windows.Forms.Button button_clickgui_hotkey;
        private System.Windows.Forms.Button button_clickgui;
        private System.Windows.Forms.Panel panel_tabgui;
        private System.Windows.Forms.Button button_tabgui_h;
        private System.Windows.Forms.Button button_tabgui;
        private System.Windows.Forms.Panel panel_arraylist;
        private System.Windows.Forms.Button button_arraylist_h;
        private System.Windows.Forms.Button button_arraylist;
        private System.Windows.Forms.Panel panel_watermark;
        private System.Windows.Forms.Button button_watermark_h;
        private System.Windows.Forms.Button button_watermark;
        private System.Windows.Forms.Panel panel_aimbot;
        private System.Windows.Forms.Button button_aimbot_h;
        private System.Windows.Forms.Button button_aimbot;
        private System.Windows.Forms.Panel panel_entitydisplay;
        private System.Windows.Forms.Button button_entitydisplay_h;
        private System.Windows.Forms.Button button_entitydisplay;
        private System.Windows.Forms.Panel panel_targetstraffe;
        private System.Windows.Forms.Button button_targetstraffe_h;
        private System.Windows.Forms.Button button_tragtetstraffe;
        private System.Windows.Forms.Panel panel_kompass;
        private System.Windows.Forms.Button button_kompass_h;
        private System.Windows.Forms.Button button_kompass;
        private System.Windows.Forms.Timer timer_aimbot;
        private System.Windows.Forms.TrackBar trackBar3;
        public System.Windows.Forms.TrackBar trackBar_hitbox_withe;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.ComponentModel.IContainer components;
    }
}

