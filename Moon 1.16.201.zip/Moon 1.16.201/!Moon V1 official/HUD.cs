﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ezOverLay;

namespace _Moon_V1_official
{
    public partial class HUD : Form
    {
        public HUD()
        {
            InitializeComponent();
        }

        private void HUD_Load(object sender, EventArgs e)
        {

        }
    }
}
