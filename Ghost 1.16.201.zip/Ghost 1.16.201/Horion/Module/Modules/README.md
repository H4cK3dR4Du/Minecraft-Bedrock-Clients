# Ghost-1-16-Old
 old version of ghost client, leaked by rxversed @ discord.gg/killaura
